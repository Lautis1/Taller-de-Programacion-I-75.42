#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#define MAX_POZOS 20
#define MAX_TANQUES 20
#define PASO 0.0001

static int cant_tanques = 0;
static int cant_pozos = 0;

struct Tanque{
	char id[20];
	double x;
	double y;
	char direccion;
	double distancia;
	bool cayo;
	bool termino;
	char id_pozo[20];
};

struct Pozo{
	char id[20];
	double x;
	double y;
	double radio;
};

struct Tanque tanques[MAX_TANQUES];
struct Pozo pozos[MAX_POZOS];

void inicializarTanques(char* nombre_archivo);
void inicializarPozos(char* nombre_archivo);
void imprimir();
int comparar(const void* a,const void* b);
void actualizar();
bool seguir();
void hallarColision();
void mover();
bool hayColision(int i,int j);

int main(int argc,char *argv[]){

	if ( argc != 3 ){
		printf("%s\n","No se ingreso la cantidad de argumentos correcta." );
		exit(1);
	}

	// Inicializar tanques:
	inicializarTanques(argv[1]);

	// Inicializar pozos:
	inicializarPozos(argv[2]);

	//Actualizar:
	actualizar();

	//Imprimir resultados
	imprimir();

	return 0;
}

void inicializarTanques(char* nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");
	char linea[256];

	if ( archivo == NULL ){
		printf("No se pudo abrir el archivo %s\n",nombre_archivo);
		exit(1);
	}

	while( fgets(linea,sizeof(linea),archivo) ){

		sscanf(linea,"%s %lf %lf %c",tanques[cant_tanques].id,
			&tanques[cant_tanques].x,&tanques[cant_tanques].y,
			&tanques[cant_tanques].direccion);

		tanques[cant_tanques].cayo = false;
		tanques[cant_tanques].termino = false;
		tanques[cant_tanques].distancia = 0.0;
		strcpy(tanques[cant_tanques].id_pozo,"");
		cant_tanques++;
	}

	fclose(archivo);
}

void inicializarPozos(char* nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");
	char linea[256];

	if ( archivo == NULL ){
		printf("No se pudo abrir el archivo %s\n",nombre_archivo);
		exit(1);
	}

	while( fgets(linea,sizeof(linea),archivo) ){

		sscanf(linea,"%s %lf %lf %lf",pozos[cant_pozos].id,
			&pozos[cant_pozos].x,&pozos[cant_pozos].y,
			&pozos[cant_pozos].radio);

		cant_pozos++;
	}

	fclose(archivo);
}

void imprimir(){

	qsort(tanques,cant_tanques,sizeof(struct Tanque),comparar);

	for (int i = 0; i < cant_tanques; i++){

		if ( tanques[i].cayo ){
			printf("ID TANQUE: %s;ID POZO: %s;DISTANCIA: %lf\n",tanques[i].id,tanques[i].id_pozo,tanques[i].distancia );
		}

	}
}

int comparar(const void* a,const void* b){

	struct Tanque* t1 = (struct Tanque*)a;
	struct Tanque* t2 = (struct Tanque*)b;

	return (int)( t1->distancia >= t2->distancia);
}

void actualizar(){

	while( seguir() ){
		hallarColision();
		mover();
	}
}

bool seguir(){

	for(int i = 0; i < cant_tanques;i++){
		if ( ! tanques[i].termino ){
			return true;
		}
	}
	return false;
}

void hallarColision(){

	for(int i = 0; i < cant_tanques;i++){

		if (tanques[i].termino){
			continue;
		}
		for (int j = 0; j < cant_pozos; j++)
		{
			if ( hayColision(i,j) ){
				tanques[i].termino = true;
				tanques[i].cayo = true;
				strcpy(tanques[i].id_pozo,pozos[j].id);
			}
		}
	}
}

bool hayColision(int i,int j){

	double distancia = sqrt(pow((tanques[i].x - pozos[j].x),2) + pow((tanques[i].y - pozos[j].y),2));

	return ( distancia <= pozos[j].radio );
}

void mover(){

	for(int i=0;i<cant_tanques;i++){

		int cantidad_pozos_superados = 0;

		if ( tanques[i].termino ){
			continue;
		}
		if ( tanques[i].direccion == 'H' ){
			tanques[i].x += PASO;
			tanques[i].distancia += PASO;
		}
		else{
			tanques[i].y += PASO;
			tanques[i].distancia += PASO;
		}
		for ( int j = 0; j < cant_pozos;j++){
			
			if ( tanques[i].direccion == 'H' &&  (tanques[i].x > (pozos[j].x + pozos[j].radio)) ){
				cantidad_pozos_superados++;
			}
			else if ( tanques[i].direccion == 'V' &&  (tanques[i].y > (pozos[j].y + pozos[j].radio)) ){
				cantidad_pozos_superados++;
			}		
		}
		tanques[i].termino = (cantidad_pozos_superados == cant_pozos);
	}
}