#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define MAX_TANQUES 100
#define MAX_POZOS 100
#define MAX_STR 100

const char HORIZONTAL = 'H';
const char VERTICAL = 'V';
const double PASO = 0.001;
const double D_PI = 2 * 3.14159265358979;

int c_p = 0;
int c_t = 0;
double max_x = -1.0;
double max_y = -1.0;

typedef struct pozo{
    char id[MAX_STR];
    double xc;
    double yc;
    double r;
} pozo_t;

typedef struct tanque{
    char id[MAX_STR];
    double x;
    double y;
    char dir;
    pozo_t* p;
    double distancia;
} tanque_t;

bool cargar_pozos(char* ruta, pozo_t* p){
    FILE* archivo = fopen(ruta, "r");
    char linea[MAX_STR];
    
    if(!archivo){
        return false;
    }
    
    for(int i = 0; fgets(linea, sizeof(linea), archivo); i += 1){
        sscanf(linea, "%s %lf %lf %lf", p[i].id, &p[i].xc, &p[i].yc, &p[i].r);
        c_p += 1;
        
        if( ( p[i].xc + p[i].r ) > max_x ) {
            max_x =  p[i].xc + p[i].r;
        }
        
        if( ( p[i].yc + p[i].r ) > max_y ) {
            max_y =  p[i].yc + p[i].r;
        }
    }

    fclose(archivo);
    return true;
}

bool cargar_tanques(char* ruta, tanque_t* t){
    FILE* archivo = fopen(ruta, "r");
    char linea[MAX_STR];
    
    if(!archivo){
        return false;
    }
    
    for(int i = 0; fgets(linea, sizeof(linea), archivo); i += 1){
        t[i].p = NULL;
        t[i].distancia = 0;
        sscanf(linea, "%s %lf %lf %c", t[i].id, &t[i].x, &t[i].y, &t[i].dir);
        c_t += 1;
    }

    fclose(archivo);
    return true;
}

size_t cant_lineas(char* ruta){
    FILE* archivo = fopen(ruta, "r");
    char linea[MAX_STR];
    
    if(!archivo){
        return 0;
    }
    
    int i;
    for(i = 0; fgets(linea, sizeof(linea), archivo); i += 1);

    fclose(archivo);
    return i;
}

bool hay_colisiones(tanque_t* t){
    for(int i = 0; i < c_t; i += 1){
        if( ( t[i].dir == HORIZONTAL ) && ( t[i].x < max_x ) && (! t[i].p) ){
            return true;
        }
        
        if( ( t[i].dir == VERTICAL ) && ( t[i].y < max_y )  && (! t[i].p) ){
            return true;
        }
    }
    
    return false;
}

/* Si cambia, lo "paso por referncia". */
void mover(tanque_t* t){
    if( t->p ){
        return;
    }
    
    if( t->dir == HORIZONTAL ){
        t->x += PASO;
        t->distancia += PASO;
    }
    
    else if( t->dir == VERTICAL ){
        t->y += PASO;
        t->distancia += PASO;
    }
}

bool hay_colision(tanque_t t, pozo_t p){
     if(t.p){
         return false;
     }
    
    double d_t = sqrt( (p.xc - t.x) * (p.xc - t.x) + (p.yc - t.y) * (p.yc - t.y) );
        
     if(d_t <= p.r){
         return true;
    }
    
    return false;
}

/* Si cambia, lo "paso por referncia". */
void actualizar(tanque_t* t, pozo_t* p){
    while( hay_colisiones(t) ){
        for(int i = 0; i < c_t; i += 1){
            for(int j = 0; j < c_p; j += 1){
                if( hay_colision( t[i], p[j] ) ){
                    t[i].p = &p[j];
                    printf("==== \n");
                }
            }
            
            mover( &t[i] );
        }
    }
}

int comparar_tanques(const void* a, const void* b){
    tanque_t t1 = *(tanque_t*) a;
    tanque_t t2 = *(tanque_t*) b;
    
    if(t1.distancia > t2.distancia){
        return 1;
    }
    
    if(t2.distancia > t1.distancia){
        return -1;
    }
    
    return 0;
}

void mostar_caidos(tanque_t* t){
    qsort(t, c_t, sizeof(tanque_t), comparar_tanques);
    
    for(int i = 0; i < c_t; i += 1){
        if( t[i].p ){
            printf("%s %s %lf \n", t[i].id, ( *(t[i].p) ).id, t[i].distancia);
        }
    }
    
}

int main(int argc, char* argv[]){
    (void) argc;
    
    const size_t l_t = cant_lineas( argv[1] );
    const size_t l_p = cant_lineas( argv[2] );
    
    if( ( l_t == 0 ) || ( l_p == 0 ) ){
        printf("Archivo no encontrado o sin líneas. \n");
        return 1;
    }
    
    tanque_t t[l_t];
    pozo_t  p[l_p];
    
    if( ( !cargar_tanques(argv[1], t) ) || ( !cargar_pozos(argv[2], p) ) ){
        printf("Archivo no encontrado \n");
        return 1;
    }
    
    actualizar(t, p);
    mostar_caidos(t);
    return 0;
}