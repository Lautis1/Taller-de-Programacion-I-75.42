#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <ctype.h>

#define MAX_ID 64
#define MAX_POZOS 64
#define MAX_TANQUES 64

#define DELTA 1e-5

typedef struct {
	char id[MAX_ID];
	double x;
	double y;
	double radio;
} pozo_t;

typedef struct {
	char id[MAX_ID];
	double x;
	double y;
	bool dir_vertical;
	double distancia;
} tanque_t;

typedef struct {
	char *id_tanque;
	char *id_pozo;
	double distancia;
} caidos_t;


/*
	Dado que los tanques son un punto en el espacio y no tienen una cantidad de vidas (solo me interesa la primera interseccion con un pozo), no hace falta simular
	paso a paso de forma discreta el sistema, sino que puedo hallar la solución viendo para cada tanque si al desplazarse en la direccion indicada es posible que choque
	con un pozo y en el caso de que sea posible que choque con varios quedarme con el que se chocaria a menor distancia.

	Si la posicion inicial del tanque esta dentro del radio de un pozo, considero la distancia 0, si no calculo la distancia al pozo con el que me podria chocar como 
	la diferencia entre la posicion incial del tanque y lo que tengo que avanzar en la direccion indicada para quedar alineado con el pozo y a eso le resto 
	la distancia hasta la interseccion. (Ver foto adjunta, busco el tramo "d").

	Para saber como es el tramo B (seccion verde en la figura) que tengo que restarle a la diferencia entre la posicion incial del tanque y la posicion del pozo 
	(Tramo D rojo en la figura) lo que hago depende de si la direccion es horizontal o vertical:
	- Si la direccion es horizontal, entonces el tramo B será el coseno del angulo de la interseccion de la recta con el circulo (tomado positivo) multiplicado por el radio, ese coseno
	  lo puedo calcular como la raiz cuadrada de 1 - sen^2(angulo)) y se de antemano que sen^2(angulo) es igual a abs(y_pozo - y_tanque) dividido por el radio.
	- Equivalentemente, si la direccion es vertical entonces el tramo B será el (modulo del) seno del angulo de la interseccion multiplicado por el radio, ese seno lo puedo calcular como
	  la raiz cuadrada de 1 - cos^2(angulo) y se de antemano que cos^2(angulo) es igual a abs(x_pozo-x_tanque) dividido por el radio.
	
*/


//Lee los datos del archivo pozos.txt y lo guarda en la lista de pozos recibida, devuelve la cantidad de pozos leidos en caso de exito o -1 en caso de error
int leer_pozos(pozo_t* pozos);
//Lee los datos del archivo tanques.txt y lo guarda en la lista de tanques recibida, devuelve la cantidad de tanques leidos en caso de exito o -1 en caso de error
int leer_tanques(tanque_t* tanques);
//Devuelve la distancia entre los puntos (x1, y1) y (x2, y2)
double distancia(double x1, double y1, double x2, double y2);
//Verifica si es posible que el tanque se pueda chocar con el pozo y en el caso de que sea posible asigna la distancia a la que sucederia en la variable dist
bool verificar_colision_posible(tanque_t* tanque, pozo_t* pozo, double *dist);
//Verifica si puede haber colision de un tanque con algun pozo y guarda en el vector caidos el nombre del pozo y el del tanque que chocaron a la menor distancia posible
void verificar_colision(tanque_t* tanque, pozo_t* pozos, int cant_pozos, caidos_t* caidos, int* cant_caidos);
//Procesa si los tanques se caen en los pozos y guarda los que se hayan caido en la lista de caidos, devuelve la cantidad de caidos
int procesar(tanque_t* tanques, int cant_tanques, pozo_t* pozos, int cant_pozos, caidos_t* caidos);
//True si caido_1 > caido_2, para ordenar lista de personajes de forma ascendente
int comparar(const void *caido_1, const void *caido_2);
//Imprime la lista de caidos ordenada por distancia
void imprimir_resultado(caidos_t* caidos, int cant_caidos);

int leer_pozos(pozo_t* pozos) {
	FILE* archivo = fopen("pozos.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro el archivo de input de pozos 'pozos.txt'\n");
		return -1;
	}
	int res_leer_linea = 1;
	int cant_pozos = 0;
	while (res_leer_linea != EOF && cant_pozos < MAX_POZOS) {
		res_leer_linea = fscanf(archivo, "%s %lf %lf %lf", pozos[cant_pozos].id, &(pozos[cant_pozos].x), &(pozos[cant_pozos].y), &(pozos[cant_pozos].radio));
		if (res_leer_linea != EOF) {
			cant_pozos += 1;
		}
		
	}
	fclose(archivo);
	return cant_pozos;
}

int leer_tanques(tanque_t* tanques) {
	FILE* archivo = fopen("tanques.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro el archivo de input de tanques 'tanques.txt'\n");
		return -1;
	}
	int res_leer_linea = 1;
	int cant_tanques = 0;
	char dir = 0;
	while (res_leer_linea != EOF && cant_tanques < MAX_TANQUES) {
		res_leer_linea = fscanf(archivo, "%s %lf %lf %c", tanques[cant_tanques].id, &(tanques[cant_tanques].x), &(tanques[cant_tanques].y), &dir);
		if (res_leer_linea != EOF && tolower(dir) == 'h') {
			tanques[cant_tanques].dir_vertical = false;
			cant_tanques += 1;
		} else if (res_leer_linea != EOF && tolower(dir) == 'v') {
			tanques[cant_tanques].dir_vertical = true;
			cant_tanques += 1;
		}
	}
	fclose(archivo);
	return cant_tanques;
}

double distancia(double x1, double y1, double x2, double y2) {
	return sqrt(((x1 - x2)*(x1 - x2)) + ((y1 - y2)*(y1 - y2)));
}	

bool verificar_colision_posible(tanque_t* tanque, pozo_t* pozo, double *dist) {
	//Para verificar que la colision sea posible veo si avanzando en la direccion indicada (siempre positiva)
	//la distancia (vertical u horizontal) que hay entre el centro del pozo y el tanque quedo dentro del radio del pozo o no.
	double distacia_aux;
	if (tanque->dir_vertical) {
		distacia_aux = distancia(tanque->x, tanque->y + fabs(pozo->y - tanque->y), pozo->x, pozo->y);
	} else {
		distacia_aux = distancia(tanque->x + fabs(pozo->x - tanque->x), tanque->y, pozo->x, pozo->y);
	}
	bool colision_posible = distacia_aux < pozo->radio + DELTA;
	//Si la colision es posible calculo la distancia a la que chocaria
	if (colision_posible) {
		printf("Colision posible de tanque %s, con dir vertical: %d a ", tanque->id, tanque->dir_vertical);
		if (tanque->dir_vertical) {
			printf("distancia: %lf - %lf == %lf\n", fabs(pozo->y - tanque->y), sqrt(1 - (fabs(pozo->x - tanque->x) / pozo->radio)) * pozo->radio, fabs(pozo->y - tanque->y) - sqrt(1 - (fabs(pozo->x - tanque->x) / pozo->radio)) * pozo->radio);

			//sen = sqrt(1-cos^2)
			*dist = fabs(pozo->y - tanque->y) - sqrt(1 - ((fabs(pozo->x - tanque->x) / pozo->radio)*(fabs(pozo->x - tanque->x) / pozo->radio))) * pozo->radio;		
		} else {
			printf("distancia: %lf - %lf == %lf\n", fabs(pozo->x - tanque->x), sqrt(1 - (fabs(pozo->y - tanque->y) / pozo->radio)) * pozo->radio, fabs(pozo->x - tanque->x) - sqrt(1 - (fabs(pozo->y - tanque->y) / pozo->radio)) * pozo->radio);

			//cos = sqrt(1-sen^2)
			*dist = fabs(pozo->x - tanque->x) - sqrt(1 - ((fabs(pozo->y - tanque->y) / pozo->radio)*(fabs(pozo->y - tanque->y) / pozo->radio))) * pozo->radio;
		}
	}
	return colision_posible;
}

void verificar_colision(tanque_t* tanque, pozo_t* pozos, int cant_pozos, caidos_t* caidos, int* cant_caidos) {
	int cant_caidos_original = *cant_caidos;
	double dist;
	bool se_pueden_chocar = false;
	for (int i = 0; i < cant_pozos; ++i) {
		se_pueden_chocar = false;
		dist = 0;
		if (distancia(tanque->x, tanque->y, pozos[i].x, pozos[i].y) < pozos[i].radio) {
			//Se chocan con distancia = 0, porque ya esta en el pozo
			se_pueden_chocar = true;
		} else if (verificar_colision_posible(tanque, &pozos[i], &dist)) {
			//Se van a chocar con distancia dist
			se_pueden_chocar = true;
		}
		if (se_pueden_chocar) {
			if (*cant_caidos == cant_caidos_original || caidos[*cant_caidos].distancia < dist) {
				caidos[*cant_caidos].id_tanque = tanque->id;
				caidos[*cant_caidos].id_pozo = pozos[i].id;
				caidos[*cant_caidos].distancia = dist;
			}
			if (*cant_caidos == cant_caidos_original) {
				*cant_caidos += 1;
			}
		}
	}
}

int procesar(tanque_t* tanques, int cant_tanques, pozo_t* pozos, int cant_pozos, caidos_t* caidos) {
	int cant_caidos = 0;
	for (int i = 0; i < cant_tanques; ++i) {
		verificar_colision(&tanques[i], pozos, cant_pozos, caidos, &cant_caidos);
	}
	return cant_caidos;
}

//True si caido_1 > caido_2, para ordenar lista de personajes de forma ascendente
int comparar(const void *caido_1, const void *caido_2) {
	//positive if c1_dist > c2_dist
	caidos_t *c1 = (caidos_t *)caido_1;
	caidos_t *c2 = (caidos_t *)caido_2;
	return (int)(c1->distancia > c2->distancia);
}

void imprimir_resultado(caidos_t* caidos, int cant_caidos) {
	qsort(caidos, cant_caidos, sizeof(caidos_t), comparar);
	printf("\n\nRESULTADO: \n");
	for (int i = 0; i < cant_caidos; ++i) {
		fprintf(stdout, "%s: se cayo en %s habiendo recorrido una distancia de %lf\n", caidos[i].id_tanque, caidos[i].id_pozo, caidos[i].distancia);
	}
}

int main(void) {
	pozo_t pozos[MAX_POZOS];
	int cant_pozos;
	if ((cant_pozos = leer_pozos(pozos)) < 0)
		return cant_pozos;
	
	for (int i = 0; i < cant_pozos; ++i) {
		printf("Pozo: %s, x: %lf, y: %lf, radio: %lf\n", pozos[i].id, pozos[i].x, pozos[i].y, pozos[i].radio);
	}

	tanque_t tanques[MAX_TANQUES];
	int cant_tanques;
	if ((cant_tanques = leer_tanques(tanques)) < 0)
		return cant_tanques;

	for (int i = 0; i < cant_tanques; ++i) {
		printf("Tanque: %s, x: %lf, y: %lf, dir_vertical: %d\n", tanques[i].id, tanques[i].x, tanques[i].y, tanques[i].dir_vertical);
	}

	caidos_t caidos[MAX_TANQUES];
	int cant_caidos = 0;
	cant_caidos = procesar(tanques, cant_tanques, pozos, cant_pozos, caidos);

	for (int i = 0; i < cant_caidos; ++i) {
		printf("Caidos: id_tanque: %s, id_pozo: %s, distancia: %lf\n", caidos[i].id_tanque, caidos[i].id_pozo, caidos[i].distancia);
	}

	imprimir_resultado(caidos, cant_caidos);

	return 0;
}

