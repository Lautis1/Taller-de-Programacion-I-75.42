#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

const int MAX_ENEMIGOS = 9990;
const int MAX_PERSONAJES = 10;
const int FIN_POSICION_X = 99;

typedef struct {
	int x;
	int y;
	double ataque;
	int alcance;
}Enemigo;

typedef struct {
	char id[10];
	int x;
	int y;
	int cant_celdas;
	int cant_ciclos;
	double energia;
	double escudo;
	bool vivo;
	bool movimiento;
}Personaje;


//verifica los parámetros de entrada del programa
int verificarArgumentos(int argc, char *argv[]) {
    if (argc == 3) {
        return 0;
    }
    fprintf(stderr, "%s\n", "Error: Numero de parametros incorrecto. Se necesitan 2 archivos");
    return -1;
}

//Lee el archivo de enemigos y los carga.
int cargarEnemigos(char *argv[], Enemigo *enemigos){
	 FILE *archivo_enemigos = fopen(argv[1],"r");
    
	if(!archivo_enemigos){
		fprintf(stderr, "Error, no se puede abrir el archivo de enemigos\n");
		return -1;
	}
	
	char linea[128];
	int cantidad_enemigos = 0;
	while (fgets(linea,sizeof(linea),archivo_enemigos) && cantidad_enemigos < MAX_ENEMIGOS){
		
		sscanf(linea,"%d %d %lf %d\n",&enemigos[cantidad_enemigos].x, &enemigos[cantidad_enemigos].y, &enemigos[cantidad_enemigos].ataque, &enemigos[cantidad_enemigos].alcance);
		cantidad_enemigos++;
	}

	fclose(archivo_enemigos);
	return cantidad_enemigos;
	
}
  
//Lee el archivo de personajes y los carga.
int cargarPersonajes(char *argv[], Personaje *personajes, Enemigo *enemigos, int cant_enemigos){
	 FILE *archivo_personajes = fopen(argv[2],"r");
    
	if(!archivo_personajes){
		fprintf(stderr, "Error, no se puede abrir el archivo de personajes\n");
		return -1;
	}
	
	char linea[128];
	int cantidad_personajes = 0;
	while (fgets(linea,sizeof(linea),archivo_personajes) && cantidad_personajes < MAX_PERSONAJES){
		
		char id[10];
		int x;
		int y;
		double energia;
		double escudo;
		
		sscanf(linea,"%s %d %d %lf %lf\n",id, &x, &y, &energia, &escudo);
		
		bool cargar_personaje = true;
		bool puede_moverse = true;
		for(int i = 0; i < cant_enemigos; i++){
			Enemigo enemigo = enemigos[i];
			if(enemigo.x == x && enemigo.y == y){
				cargar_personaje = false;
			}
			if(enemigo.x == x+1 && enemigo.y == y){
				puede_moverse = false;
			}
		}
		
		if(!cargar_personaje){
			fprintf(stdout, "No se puedo cargar el personaje con id: %s en la pos (%d,%d). La posicion tiene un enemigo.\n",id, x ,y);
			continue;
		}
		strcpy (personajes[cantidad_personajes].id,id);
		personajes[cantidad_personajes].x = x;
		personajes[cantidad_personajes].y = y;
		personajes[cantidad_personajes].energia = energia;
		personajes[cantidad_personajes].escudo = escudo;
		personajes[cantidad_personajes].vivo = true;
		personajes[cantidad_personajes].cant_celdas = 0;
		personajes[cantidad_personajes].cant_ciclos = 1;
		personajes[cantidad_personajes].movimiento = puede_moverse;

		cantidad_personajes++;
	}

	fclose(archivo_personajes);
	return cantidad_personajes;
}

//Verifica si el personaje esta al alcance del ataque del enemigo
bool estaEnAlcance(Enemigo enemigo,Personaje personaje){
	int distancia_x = abs( personaje.x - enemigo.x);
	int distancia_y = abs( personaje.y - enemigo.y);
	return ((distancia_y <= enemigo.alcance ) && ( distancia_x <= enemigo.alcance )) ;
}

//Ejecuta el ataque del enemigo al personaje
void atacar(Enemigo enemigo, Personaje* personajes, int pos){
	if(estaEnAlcance(enemigo,personajes[pos]) && personajes[pos].vivo){
		double energia_ataque = enemigo.ataque;
		double escudo = personajes[pos].escudo;
		if(escudo < energia_ataque){
			personajes[pos].energia = personajes[pos].energia - (energia_ataque - escudo);

		}
		if(personajes[pos].energia <= 0){
			personajes[pos].vivo = false;
		}
	}
}

//Ejecuta los ataque de los enemigos a los personajes
void ataqueEnemigos(Enemigo *enemigos,int cant_enemigos, Personaje *personajes, int cant_personajes){
	for(int i = 0; i < cant_enemigos; i++){
		Enemigo enemigo = enemigos[i];
		for(int j = 0; j < cant_personajes; j++){
			atacar(enemigo, personajes, j);
		}
	}
}

//Verifica que el personaje se pueda mover.
bool puedeMoverse(Personaje personaje, Enemigo *enemigos, int cant_enemigos){
	for(int i = 0; i < cant_enemigos; i++){
		Enemigo enemigo = enemigos[i];
		if(enemigo.y == personaje.y && (personaje.x + 1) == enemigo.x){
			return false;
		}
	}
	return personaje.x != FIN_POSICION_X;
}

//Ejecuta los movimientos de los personajes
void movimientoPersonajes(Enemigo *enemigos,int cant_enemigos, Personaje *personajes, int cant_personajes){
	for(int i = 0; i < cant_personajes; i++){
		if(personajes[i].vivo){
			if(personajes[i].movimiento){
				personajes[i].x = personajes[i].x + 1;
				personajes[i].cant_celdas = personajes[i].cant_celdas + 1;
				personajes[i].movimiento = puedeMoverse(personajes[i], enemigos, cant_enemigos);
			}
		
			personajes[i].cant_ciclos = personajes[i].cant_ciclos + 1;
		}
	}
}

//Verificar que no se puedan mover mas los personajes
bool finIteraciones(Personaje *personajes, int cant_personajes){
	bool fin = true;
	for(int i = 0; i < cant_personajes; i++){
		Personaje personaje = personajes[i];
		if(personaje.vivo && personaje.movimiento){
			fin = fin && false;
		}
	}
	return fin;
}

int comparador(const void *a, const void *b){

	Personaje *p1 = (Personaje*)a;
	Personaje *p2 = (Personaje*)b;

	return (int)(p1->cant_ciclos - p2->cant_ciclos);
}

//imprime por stdout las estadistica de los personajes
void imprimirEstadisticas(Personaje *personajes, int cant_personajes){
	Personaje personajes_muertos[MAX_PERSONAJES];
	int cant_personajes_muertos = 0;
	for(int i = 0; i < cant_personajes; i++){
		Personaje personaje = personajes[i];
		if(!personaje.vivo){
			personajes_muertos[cant_personajes_muertos] = personaje;
			cant_personajes_muertos = cant_personajes_muertos + 1;
		}
	}
	qsort(personajes_muertos,cant_personajes_muertos,sizeof(Personaje), comparador);
	for(int j = 0; j < cant_personajes_muertos; j++){
		Personaje personaje_muerto = personajes_muertos[j];
		fprintf(stdout, "%s: - cantidad de celdas recorridas: %d - cantidad de ciclos vivo: %d\n",personaje_muerto.id, personaje_muerto.cant_celdas , personaje_muerto.cant_ciclos);
	}
}


int main(int argc, char *argv[]) {
	int r = verificarArgumentos(argc, argv);
    if (r < 0) {
        return -r;
    }
  
    Enemigo enemigos[MAX_ENEMIGOS];
    Personaje personajes[MAX_PERSONAJES];
    int cantidad_personajes;
    int cantidad_enemigos;
    
    cantidad_enemigos = cargarEnemigos(argv, enemigos);
    if (cantidad_enemigos < 0) {
        return -r;
    }
    cantidad_personajes = cargarPersonajes(argv,personajes, enemigos, cantidad_enemigos);
    if (cantidad_personajes < 0) {
        return -r;
    }
    
    if (cantidad_personajes == 0) {
		fprintf(stdout, "No se cargaron personajes desde el archivo\n");
        return 0;
    }
    
    bool fin = false;
    
    while (!fin){
		ataqueEnemigos(enemigos, cantidad_enemigos, personajes, cantidad_personajes);
		movimientoPersonajes(enemigos, cantidad_enemigos, personajes, cantidad_personajes);
		fin = finIteraciones(personajes, cantidad_personajes);
	}
	
	imprimirEstadisticas(personajes, cantidad_personajes);
	return 0;
}

