#include<stdlib.h>
#include<stdio.h>
#include <stdbool.h>
#include <string.h>

const int MAXIMO_PERSONAJES = 10;
const int MOV_CELDAS = 1;
const int LARGO_Y_ANCHO = 100;

struct Enemigo{
	int x;
	int y;
	double ataque;
	int alcance;
};

struct Personaje{
	char id[20];
	int x;
	int y;
	double energia;
	double escudo;
	bool llego_a_su_fin;
	int distancia;
	bool vivo;
	int ciclo;
};


static int cantidad_personajes = 0;
static int cantidad_enemigos = 0;

void inicializarPersonajes(char* nombre_archivo,struct Personaje *personajes);
void inicializarEnemigos(char* nombre_archivo,struct Enemigo *enemigos);
void actualizar(struct Personaje *personajes,struct Enemigo *enemigos);
void mostrar(struct Personaje *personajes);
bool seguir(struct Personaje *personaje);
void atacar(struct Personaje *personaje,struct Enemigo *enemigos);
void mover(struct Personaje *personaje,struct Enemigo *enemigos);
void daniar(struct Personaje *personaje,struct Enemigo enemigo);
bool hayAtaque(struct Personaje personaje,struct Enemigo enemigo);
bool puedeMoverse(struct Personaje *personaje,struct Enemigo *enemigos);
void mostrar(struct Personaje *personajes);
int comparar(const void* a,const void* b);



int main(int argc, char* argv[]){

	if (argc != 3){
		printf("%s\n","No se mando dos archivos como argumentos");
		return 1;
	}

	struct Personaje personajes[MAXIMO_PERSONAJES];
	struct Enemigo enemigos[((LARGO_Y_ANCHO * LARGO_Y_ANCHO) - MAXIMO_PERSONAJES)];

	//Inicializo personajes

	inicializarPersonajes(argv[1],personajes);

	//Inicializo enemigos

	inicializarEnemigos(argv[2],enemigos);

	actualizar(personajes,enemigos);

	//Imprimo los datos:

	mostrar(personajes);

	return 0;
}


void inicializarPersonajes(char* nombre_archivo,struct Personaje *personajes){

	FILE* archivo_personajes;
	char linea[256];

	if ( (archivo_personajes = fopen(nombre_archivo,"r")) == NULL ){
		printf("No se pudo abrir el archivo.");
		exit(1);
	}

	while ( fgets(linea,sizeof(linea),archivo_personajes) ){

		sscanf(linea,"%s %d %d %lf %lf\n",personajes[cantidad_personajes].id,
			&personajes[cantidad_personajes].x,
			&personajes[cantidad_personajes].y,
			&personajes[cantidad_personajes].energia,
			&personajes[cantidad_personajes].escudo);
			
		personajes[cantidad_personajes].llego_a_su_fin = false;
		personajes[cantidad_personajes].vivo = true;
		personajes[cantidad_personajes].distancia = 0;
		personajes[cantidad_personajes].ciclo = 0;

		cantidad_personajes++;
	}

	fclose(archivo_personajes);

}

void inicializarEnemigos(char* nombre_archivo,struct Enemigo *enemigos){

	FILE* archivo_enemigos;
	char linea[256];

	if ( (archivo_enemigos = fopen(nombre_archivo,"r")) == NULL ){
		printf("%s\n","No se pudo abrir el archivo.");
		exit(1);
	}

	while ( fgets(linea,sizeof(linea),archivo_enemigos) ){

		sscanf(linea,"%d %d %lf %d\n",&enemigos[cantidad_enemigos].x,
			&enemigos[cantidad_enemigos].y,&enemigos[cantidad_enemigos].ataque,
			&enemigos[cantidad_enemigos].alcance);

		cantidad_enemigos++;
	}

	fclose(archivo_enemigos);

}


void actualizar(struct Personaje *personajes,struct Enemigo *enemigos){

	while(seguir(personajes)){
		atacar(personajes,enemigos);
		mover(personajes,enemigos);
	}

}

bool seguir(struct Personaje *personajes){


	for(int i = 0; i < cantidad_personajes; i++){

		if ( ! personajes[i].llego_a_su_fin){
			return true;
		}
	}

	return false;
}

void atacar(struct Personaje *personajes,struct Enemigo *enemigos){


	for(int i = 0; i < cantidad_personajes;i++){

		if ( personajes[i].vivo ){
			personajes[i].ciclo += MOV_CELDAS;
		}

		for(int j = 0; j < cantidad_enemigos;j++){
			
			if ( hayAtaque(personajes[i],enemigos[j]) && personajes[i].vivo ){
				daniar(&personajes[i],enemigos[j]);
			}

		}
	}


}


bool hayAtaque(struct Personaje personaje,struct Enemigo enemigo){

	int distancia_x =abs( personaje.x - enemigo.x);
	int distancia_y =abs( personaje.y - enemigo.y);

	return ( ( distancia_y <= enemigo.alcance ) && ( distancia_x <= enemigo.alcance ) ) ;
}


void daniar(struct Personaje *personajes,struct Enemigo enemigo){


	double danio = personajes->escudo - enemigo.ataque;

	//

	if ( danio <= 0 ){
		personajes->energia += danio;
		if ( personajes->energia <= 0 ){
			personajes->vivo = false;
			personajes->llego_a_su_fin = true;
		}

		
	}
}

void mover(struct Personaje *personajes,struct Enemigo *enemigos){

	for(int i = 0; i<cantidad_personajes;i++){

		if ( puedeMoverse(&personajes[i],enemigos) && personajes[i].vivo && ( ! personajes[i].llego_a_su_fin ) ){
			personajes[i].x += MOV_CELDAS; 
			personajes[i].distancia += MOV_CELDAS;
		}

		if ( personajes[i].x >= LARGO_Y_ANCHO && ( ! personajes[i].llego_a_su_fin ) ){
			personajes[i].llego_a_su_fin = true;
		}
	}

}

bool puedeMoverse(struct Personaje *personaje,struct Enemigo *enemigos){

	int nueva_x = personaje->x + MOV_CELDAS;
	int nueva_y = personaje->y;


	for ( int i = 0; i<cantidad_enemigos;i++){

		if( ( enemigos[i].x == nueva_x ) && ( enemigos[i].y == nueva_y ) ){

			personaje->llego_a_su_fin = true;
			return false;
		}


	}

	return true;
}

void mostrar(struct Personaje *personajes){

	qsort(personajes,cantidad_personajes,sizeof(struct Personaje),comparar);

	for ( int i = 0; i < cantidad_personajes;i++ ){

		if ( ! personajes[i].vivo ){
			printf("ID: %s  DISTANCIA: %d  NRO_CICLOS: %d\n",personajes[i].id,personajes[i].distancia,personajes[i].ciclo);
		}
	}
}

int comparar(const void* a,const void* b){

	struct Personaje *p1 = ( struct Personaje* )a;
	struct Personaje *p2 = ( struct Personaje* )b;

	return (int)(p1->ciclo > p2->ciclo);
}