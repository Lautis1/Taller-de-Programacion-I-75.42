#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

#define MAX_ID 64
#define MAX_RECTS 64

typedef struct {
	double xi; 		//x izquierda
	double yb;		//y base
	double xd;		//x derecha
	double yh;		//y altura
	char id[MAX_ID];
} rectangulo_t;

typedef struct {
	double xi; 		//x izquierda
	double yb;		//y base
	double xd;		//x derecha
	double yh;		//y altura
	double distancia;
	char *id_1;
	char *id_2;
	char *id_3;
} result_t;

//Devuelve -1 en caso de error o la cantidad de rectangulos leidos
int leer_rectangulos(rectangulo_t* rects) {
	FILE* archivo = fopen("rectangulos.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro el archivo 'rectangulos.txt'\n");
		return -1;
	}
	int res_leer_linea = 1;
	int cant_rects = 0;
	while(res_leer_linea != EOF && cant_rects < MAX_RECTS) {
		res_leer_linea = fscanf(archivo, "%s %lf %lf %lf %lf", rects[cant_rects].id, &(rects[cant_rects].xi), &(rects[cant_rects].yb), &(rects[cant_rects].xd), &(rects[cant_rects].yh));
		if (res_leer_linea != EOF && rects[cant_rects].xi < rects[cant_rects].xd && rects[cant_rects].yb < rects[cant_rects].yh) 
			cant_rects += 1;
	}
	fclose(archivo);
	return cant_rects;
}

//Devuelve el area de un rectangulo
double calcular_area(double xi, double yb, double xd, double yh) {
	return (xd-xi) * (yh-yb);
}

//Devuelve la distancia del punto al centro
double calcular_distancia(double xi, double yh) {
	return sqrt(xi*xi + yh*yh);
}

//Asigna los vertices del rectangulo interseccion entre rect_1 y rect_2 en el struct res
void asignar_subrectangulo(rectangulo_t *rect_1, rectangulo_t *rect_2, result_t* res) {
	res->xi = rect_1->xi > rect_2->xi ? rect_1->xi : rect_2->xi;
	res->xd = rect_1->xd < rect_2->xd ? rect_1->xd : rect_2->xd;
	res->yb = rect_1->yb > rect_2->yb ? rect_1->yb : rect_2->yb;
	res->yh = rect_1->yh < rect_2->yh ? rect_1->yh : rect_2->yh;
}

//Si hay interseccion devuelve TRUE sino devuelve false
bool hay_interseccion(rectangulo_t *rect_1, rectangulo_t *rect_2) {
	//printf("Verificando interseccion entre rectangulos xi1: %0.2lf, yb1: %0.2lf, xd1: %0.2lf, yh1: %0.2lf, xi2: %0.2lf, yb2: %0.2lf, xd2: %0.2lf, yh2: %0.2lf\n", rect_1->xi, rect_1->yb, rect_1->xd, rect_1->yh, rect_2->xi, rect_2->yb, rect_2->xd, rect_2->yh);
	if (rect_1->xi > rect_2->xd || rect_1->xd < rect_2->xi || rect_1->yb > rect_2->yh || rect_1->yh < rect_2->yb)
		return false;
	return true;
}

//Copia el subrectangulo guardado en src en el struct result_t res para que pueda ser usado para comparar interseccion contra otros rectangulos
void copiar_subrectangulo(result_t* src, result_t* res) {
	res->xi = src->xi;
	res->xd = src->xd;
	res->yb = src->yb;
	res->yh = src->yh;
	res->id_1 = src->id_1;
	res->id_2 = src->id_2;
}

//Guarda el rectangulo resultado final (interseccion entre rect_1 y rect_2) en rect_1
void asignar_subrectangulo_resultado(result_t* rect_1, rectangulo_t *rect_2) {
	asignar_subrectangulo((rectangulo_t *)rect_1, rect_2, rect_1);
	rect_1->distancia = calcular_distancia(rect_1->xi, rect_1->yh);
	rect_1->id_3 = rect_2->id;
}

int procesar(rectangulo_t* rects, int cant_rects, result_t* resultados) {
	int cant_res = 0;
	int size = 1;
	for (int i = 0; i < cant_rects - 2; ++i) {
		for (int j = i + 1; j < cant_rects - 1; ++j) {
			if (hay_interseccion(&rects[i], &rects[j])) {
				asignar_subrectangulo(&rects[i], &rects[j], &resultados[cant_res]);
				resultados[cant_res].id_1 = rects[i].id;
				resultados[cant_res].id_2 = rects[j].id;
				//printf("Interseccion con el subrectangulo xi: %0.2lf, yb: %0.2lf, xd: %0.2lf, yh: %0.2lf\n", resultados[cant_res].xi, resultados[cant_res].yb, resultados[cant_res].xd, resultados[cant_res].yh);
				for (int k = j + 1; k < cant_rects; ++k) {
					if (hay_interseccion((rectangulo_t *)(&resultados[cant_res]), &rects[k])) {
						cant_res += 1;				
						if (cant_res == size) {
							size *= 2;
							resultados = realloc(resultados, size*sizeof(result_t));
						}
						copiar_subrectangulo(&resultados[cant_res - 1], &resultados[cant_res]);
						asignar_subrectangulo_resultado(&resultados[cant_res - 1], &rects[k]);
						//printf("Interseccion con el subsubrectangulo xi: %0.2lf, yb: %0.2lf, xd: %0.2lf, yh: %0.2lf\n", resultados[cant_res-1].xi, resultados[cant_res-1].yb, resultados[cant_res-1].xd, resultados[cant_res-1].yh);
					}
				}
			}		
		}		
	}
	return cant_res;
}

//True si la distancia de res1 es mayor a distancia de res2, para ordenar de forma ascendente
//por distancia
int comparar(const void *res1, const void *res2) {
	return (int)(((result_t*)res1)->distancia > ((result_t*)res2)->distancia);
}

//Imprime los rectangulos de forma ordenada segun la distancia
void imprimir(result_t* resultados, int cant_res) {
	qsort(resultados, cant_res, sizeof(result_t), comparar);
	for (int i = 0; i < cant_res; ++i) 
		printf("Dist: %lf, area: %lf, ID1: %s, ID2: %s, ID3: %s\n", resultados[i].distancia, calcular_area(resultados[i].xi, resultados[i].yb, resultados[i].xd, resultados[i].yh), resultados[i].id_1, resultados[i].id_2, resultados[i].id_3);
	
}

int main(void) {
	rectangulo_t rectangulos[MAX_RECTS];
	int cant_rects = leer_rectangulos(rectangulos);
	if (cant_rects < 0)
		return 1;
	for (int i = 0; i < cant_rects; ++i)
		printf("Leido: %s, xi: %lf, yb: %lf, xd: %lf, yh: %lf\n", rectangulos[i].id, rectangulos[i].xi, rectangulos[i].yb, rectangulos[i].xd, rectangulos[i].yh);
	result_t *resultados = malloc(sizeof(result_t));
	int cant_res = procesar(rectangulos, cant_rects, resultados);
	imprimir(resultados, cant_res);
	free(resultados);
	return 0;
}






