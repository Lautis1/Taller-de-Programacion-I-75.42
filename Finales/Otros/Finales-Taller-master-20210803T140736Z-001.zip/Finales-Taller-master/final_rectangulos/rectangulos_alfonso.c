#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

#define MAX_RECT 100
#define NO_HAY_RECTANGULO "NO HAY"
#define HAY_RECTANGULO "HAY"

typedef struct 
{	
	char id[20];
	float xii;
	float yii;
	float xsd;
	float ysd;

} Rectangulo_t;

typedef struct 
{	
	char id_uno[20];
	char id_dos[20];
	char id_tres[20];
	float area;
	float distancia;
	
} Respuesta_t;

static int cant_rectangulos = 0;
static int cant_respuestas = 0;

void inicializarRect(Rectangulo_t *rectangulos,char* nombre_archivo);
void procesar(Rectangulo_t *rectangulos,Respuesta_t *respuestas);
void hallarAreaDist(Rectangulo_t r1,Rectangulo_t r2,Rectangulo_t r3,Respuesta_t* resp);
void mostrar(Respuesta_t* resp);
int comparar(const void* a,const void* b);
void calcularInterseccion(Rectangulo_t r1, Rectangulo_t r2, Rectangulo_t* i);
void hallarAreaDist(Rectangulo_t r1,Rectangulo_t r2,Rectangulo_t r3,Respuesta_t* resp);

int main(int argc,char *argv[]){

	if ( argc != 2 ){
		printf("%s\n","No se envio la cantidad de argumentos correcta, solo mandar el archivo de rectangulos." );
		exit(1);
	}

	Rectangulo_t rectangulos[MAX_RECT];
	Respuesta_t respuestas[MAX_RECT];

	// Inicializacion de rectangulos:
	inicializarRect(rectangulos,argv[1]);

	if ( cant_rectangulos <= 2 ){
		printf("%s\n","Solo hay dos rectangulos en la lista, tiene que haber tres o mas." );
		exit(0);
	}

	// Proceso los rectangulos:
	procesar(rectangulos,respuestas);

	// muestro los resultados:
	mostrar(respuestas);

	return 0;
}

void inicializarRect(Rectangulo_t *rectangulos,char* nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");
	char linea[256];

	if ( archivo == NULL ){
		printf("%s\n","No se pudo abrir el archivo de rectangulos.");
		exit(1);
	}

	while(fgets(linea,sizeof(linea),archivo)){
		sscanf(linea,"%s %f %f %f %f\n",rectangulos[cant_rectangulos].id,
							&rectangulos[cant_rectangulos].xii,&rectangulos[cant_rectangulos].yii,
							&rectangulos[cant_rectangulos].xsd,&rectangulos[cant_rectangulos].ysd);
		cant_rectangulos++;
	}
	fclose(archivo);
}

void procesar(Rectangulo_t *r,Respuesta_t *respuestas){

	for(int i = 0;i<cant_rectangulos;i++){
		for(int j = i+1;j<cant_rectangulos;j++){
			for(int k = j + 1;k<cant_rectangulos;k++){
				hallarAreaDist(r[i],r[j],r[k],respuestas);
			}
		}
	}
}

void hallarAreaDist(Rectangulo_t r1,Rectangulo_t r2,Rectangulo_t r3,Respuesta_t* resp){

	Rectangulo_t r_inter_1;
	Rectangulo_t r_inter_2;

	calcularInterseccion(r1,r2,&r_inter_1);

	if ( strcmp(r_inter_1.id,NO_HAY_RECTANGULO) == 0 ){
		return;
	}

	calcularInterseccion(r_inter_1,r3,&r_inter_2);

	if ( strcmp(r_inter_2.id,NO_HAY_RECTANGULO) == 0 ){
		return;
	}

	strcpy(resp[cant_respuestas].id_uno,r1.id);
	strcpy(resp[cant_respuestas].id_dos,r2.id);
	strcpy(resp[cant_respuestas].id_tres,r3.id);

	resp[cant_respuestas].area = ( r_inter_2.xsd - r_inter_2.xii ) * ( r_inter_2.ysd - r_inter_2.yii );

	resp[cant_respuestas].distancia = sqrt(pow(r_inter_2.xii,2) + pow(r_inter_2.ysd,2));

	cant_respuestas++;
}

int comparar(const void* a,const void* b){

	Respuesta_t* r1 = (Respuesta_t*) a;
	Respuesta_t* r2 = (Respuesta_t*) b;

	return (int)(r1->distancia > r2->distancia); 
}

void mostrar(Respuesta_t* r){

	qsort(r,cant_respuestas,sizeof(Respuesta_t),comparar);

	for( int i = 0; i<cant_respuestas;i++ ){
		printf("DISTANCIA: %f; AREA: %f; ID_RECT: %s; ID_RECT: %s; ID_RECT: %s\n",r[i].distancia,r[i].area,r[i].id_uno,r[i].id_dos,r[i].id_tres);
	}
}

void calcularInterseccion(Rectangulo_t r1, Rectangulo_t r2, Rectangulo_t* i){

	strcpy(i->id,NO_HAY_RECTANGULO);

	if ( r1.ysd < r2.yii ) return;
	if ( r1.yii > r2.ysd ) return;
	if ( r1.xsd < r2.xii ) return;
	if ( r1.xii > r2.xsd ) return;

	if ( r1.xii >= r2.xii ) i->xii = r1.xii;
	else i->xii = r2.xii;

	if ( r1.xsd <= r2.xsd ) i->xsd = r1.xsd;
	else i->xsd = r2.xsd;

	if ( r1.yii >= r2.yii ) i->yii = r1.yii;
	else i->yii = r2.yii;

	if ( r1.ysd <= r2.ysd ) i->ysd = r1.ysd;
	else i->ysd = r2.ysd;

	strcpy(i->id,HAY_RECTANGULO);
}