#include <stdio.h>
#include <stdbool.h>

#define CANT_NAVES_MAX 99

const double UNIDAD_DISTANCIA = 0.01;
const double UNIDAD_TIEMPO = 0.01;
//velocidad = 0.01 / 0.01 = 1 unidad de distacia por unidad de tiempo

typedef struct Nave {
    double x;
    double y;
    char id[20];
    bool eliminada;
} nave_t;

typedef struct Disparo {
    double x;
    double y;
    char id[20];
    double tiempo;
    bool vivo;
} disparo_t;

int verificarArgumentos(int argc) {
    if (argc != 3) {
        fprintf(stderr, "La cantidad de parametros es incorrecta");
        return -1;
    }
    return 0;
}

int cargarNaves(char *argv[], nave_t *naves) {
    FILE *archivo_naves = fopen(argv[1], "r");
    if (!archivo_naves) {
        fprintf(stderr, "Error, no se pudo abril el archivo de naves\n");
        return -1;
    }
    char linea[128];
    int cantidad_naves = 0;
    while (fgets(linea, sizeof(linea), archivo_naves)) {
        sscanf(linea, "%[^,], %lf, %lf", naves[cantidad_naves].id, &naves[cantidad_naves].x, &naves[cantidad_naves].y);
        naves[cantidad_naves].eliminada = false;
        cantidad_naves++;

    }
    fclose(archivo_naves);
    return cantidad_naves;
}

int cargarDisparos(char *argv[], disparo_t *disparos) {
    FILE *archivo_disparos = fopen(argv[2], "r");
    if (!archivo_disparos) {
        fprintf(stderr, "Error, no se pudo abril el archivo de disparos\n");
        return -1;
    }
    char linea[128];
    int cantidad_disparos = 0;
    while (fgets(linea, sizeof(linea), archivo_disparos)) {
        sscanf(linea, "%[^,], %lf, %lf", disparos[cantidad_disparos].id, &disparos[cantidad_disparos].x,&disparos[cantidad_disparos].y);
        disparos[cantidad_disparos].tiempo = 0.0f;
        disparos[cantidad_disparos].vivo = true;
        cantidad_disparos++;
    }
    fclose(archivo_disparos);
    return cantidad_disparos;
}

bool continuar (nave_t *naves, int cantidad_naves, disparo_t *disparos, int cantidad_disparos){
    for (int i = 0; i < cantidad_naves; ++i) {
        if(!naves[i].eliminada){
            for (int j = 0; j < cantidad_disparos; ++j) {
                if(disparos[j].vivo){
                    return true;
                }
            }
        }
    }
    return false;
}

void ejecutarMovimiento(disparo_t *disparos, int cantidad_disparos){
    for (int i = 0; i < cantidad_disparos; ++i) {
        if(disparos[i].vivo){
            if(disparos[i].x - UNIDAD_DISTANCIA <= 0){
                disparos[i].vivo = false;
                disparos[i].tiempo += UNIDAD_TIEMPO;
                continue;
            }
            disparos[i].x -= UNIDAD_DISTANCIA;
            disparos[i].tiempo += UNIDAD_TIEMPO;
        }
    }
}

void verificarColision(nave_t *naves, int cantidad_naves, disparo_t *disparos, int cantidad_disparos){
    for (int i = 0; i < cantidad_naves; ++i){
        if(!naves[i].eliminada){
            for (int j = 0; j < cantidad_disparos; ++j){
                if(disparos[j].vivo){

                    if(disparos[j].x <= (naves[i].x + 1) && disparos[j].x >= (naves[i].x) &&
                        disparos[j].y <= (naves[i].y + 1) && disparos[j].y >= (naves[i].y)){

                         disparos[j].vivo = false;
                         naves[i].eliminada = true;
                         fprintf(stdout,"La nave: %s fue eliminada luego de %lf unidades de tiempo\n",naves[i].id,disparos[j].tiempo);
                     }
                }
            }
        }
    }
}

int main(int argc, char *argv[]) {

    int r = verificarArgumentos(argc);
    if (r < 0) {
        return -r;
    }

    nave_t naves[CANT_NAVES_MAX];
    disparo_t disparos[CANT_NAVES_MAX];

    int cantidad_naves = cargarNaves(argv, naves);

    if (cantidad_naves < 0) {
        return -r;
    }
    if (cantidad_naves == 0) {
        fprintf(stdout, "No se cargaron naves en el archivo");
        return 0;
    }

    int cantidad_disparos = cargarDisparos(argv, disparos);

    if (cantidad_disparos < 0) {
        return -r;
    }
    if (cantidad_disparos == 0) {
        fprintf(stdout, "No se cargaron disparos en el archivo");
        return 0;
    }

    while (continuar(naves,cantidad_naves,disparos,cantidad_disparos)) {
        ejecutarMovimiento(disparos,cantidad_disparos);
        verificarColision(naves,cantidad_naves,disparos,cantidad_disparos);
    }

    return 0;
}
