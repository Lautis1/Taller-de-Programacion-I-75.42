#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<math.h>

#define COTA_ERR 0.01
#define PASO 0.001
#define MAXIMO 100

typedef struct{
	char id[20];
	float x;
	float distancia;
	int z;
	bool choco;
}Personaje_t;

typedef struct{
	char id[20];
	float x;
	int z;
}Obstaculo_t;

typedef struct{
	char id[20];
	float tiempo;
	int z;
	bool tomado;
}Tiempo_t;

void iniciarEntidades(Personaje_t* personajes,Obstaculo_t *obstaculos,char*nombre);
void iniciarTiempos(Tiempo_t* tiempos,char*nombre);
void actualizar(Personaje_t* personajes,Obstaculo_t *obstaculos,Tiempo_t* tiempos);
int comparar(const void* a,const void* b);
void mostrar(Personaje_t* personajes);
void hallarColision(Personaje_t* personajes,Obstaculo_t *obstaculos);
bool seguir(Personaje_t* personajes,Obstaculo_t *obstaculos);
void mover(Personaje_t* personajes,Tiempo_t *tiempos);

static int cantidad_personajes = 0;
static int cantidad_obstaculos = 0;
static int cantidad_tiempos = 0;

int main( int argc, char* argv[] ){

	if ( argc != 3 ){
		printf("%s\n","No se ingreso la cantidad de argumentos correctas." );
		exit(1);
	}
	Personaje_t personajes[MAXIMO];
	Obstaculo_t obstaculos[MAXIMO];
	Tiempo_t tiempos[MAXIMO];

	iniciarEntidades(personajes,obstaculos,argv[1]);
	iniciarTiempos(tiempos,argv[2]);

	actualizar(personajes,obstaculos,tiempos);

	mostrar(personajes);

	return 0;
}

void iniciarEntidades(Personaje_t* personajes,Obstaculo_t *obstaculos,char*nombre){

	FILE* archivo = fopen(nombre,"r");
	char linea[256];

	if( archivo == NULL ){
		printf("%s\n","No se pudo abrir el archivo de entidades." );
		exit(1);
	}

	while(fgets(linea,sizeof(linea),archivo)){

		char id[20];
		float x;
		int z;
		char tipo;

		sscanf(linea,"%[^,], %f, %c, %d\n",id,&x,&tipo,&z);

		if ( tipo == 'P' ){
			strcpy(personajes[cantidad_personajes].id,id);
			personajes[cantidad_personajes].x = x;
			personajes[cantidad_personajes].distancia = 0;
			personajes[cantidad_personajes].z = z;
			personajes[cantidad_personajes].choco = false;
			cantidad_personajes++;
		}
		else{
			strcpy(obstaculos[cantidad_obstaculos].id,id);
			obstaculos[cantidad_obstaculos].x = x;
			obstaculos[cantidad_obstaculos].z = z;
			cantidad_obstaculos++;
		}
	}
	fclose(archivo);
}

void iniciarTiempos(Tiempo_t* tiempos,char*nombre){

	FILE* archivo = fopen(nombre,"r");
	char linea[256];

	if( archivo == NULL ){
		printf("%s\n","No se pudo abrir el archivo de tiempos." );
		exit(1);
	}

	while(fgets(linea,sizeof(linea),archivo)){

		sscanf(linea,"%f, %[^,], %d\n",&tiempos[cantidad_tiempos].tiempo,
					tiempos[cantidad_tiempos].id,&tiempos[cantidad_tiempos].z);
		tiempos[cantidad_tiempos].tomado = false;
		cantidad_tiempos++;
	}
	fclose(archivo);
}

void actualizar(Personaje_t* personajes,Obstaculo_t *obstaculos,Tiempo_t* tiempos){

	while( seguir(personajes,obstaculos) ){
		hallarColision(personajes,obstaculos);
		mover(personajes,tiempos);
	}

}

void hallarColision(Personaje_t* personajes,Obstaculo_t *obstaculos){
	
	for(int i = 0; i<cantidad_personajes;i++){

		if ( personajes[i].choco ) 
			continue;

		for(int j = 0; j<cantidad_obstaculos;j++){
			if ( fabs(personajes[i].x - obstaculos[j].x) <= COTA_ERR &&  personajes[i].z == obstaculos[j].z ){
				personajes[i].choco = true;
			}
		}
	}
}

void mover(Personaje_t* personajes,Tiempo_t *tiempos){

	for(int i = 0; i<cantidad_personajes;i++){
		if ( personajes[i].choco ) 
			continue;

		for(int j = 0; j<cantidad_tiempos;j++){
			if( tiempos[j].tomado )
				continue;

			if (( strcmp(personajes[i].id,tiempos[j].id) == 0 ) && ( personajes[i].distancia >= tiempos[j].tiempo) ){ // distancia == tiempo porque v = 1 unidad/seg
				tiempos[j].tomado = true;
				personajes[i].z = tiempos[j].z;
			}
			personajes[i].x += PASO;
			personajes[i].distancia += PASO;
		}
	}
}

bool seguir(Personaje_t* personajes,Obstaculo_t *obstaculos){

	for(int i = 0; i<cantidad_personajes;i++){
		if ( personajes[i].choco ) 
			continue;

		for(int j = 0; j<cantidad_obstaculos;j++){
			
			if( obstaculos[j].x >= personajes[i].x )
				return true;
		}
	}

	return false;
}

int comparar(const void* a, const void* b){

	Personaje_t* p1 = ( Personaje_t* )a;
	Personaje_t* p2 = ( Personaje_t* )b;
	return (int)(p1->distancia > p2->distancia );
}

void mostrar(Personaje_t* personajes){

	qsort(personajes,cantidad_personajes,sizeof(Personaje_t),comparar);

	for(int i = 0; i< cantidad_personajes;i++){

		if( personajes[i].choco ){
			printf("Id_personaje: %s; Distancia: %f\n",personajes[i].id,personajes[i].distancia);
		}
	}
}
