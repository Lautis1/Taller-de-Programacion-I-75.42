#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

const int MAX_ENTIDAD = 9990;
const char OBSTACULO = 'O';
const double ERROR = 0.01;

static int cantidad_personajes = 0;
static int cantidad_obstaculos = 0;
static int cantidad_movimientos = 0;
static int cantidad_entidades = 0;
static double x_ultimo_obstaculo = 0;

typedef struct {
    char id[20];
    double x;
    char tipo;
    int z;
    bool eliminado;
    double tiempo;
} Personaje;

typedef struct {
    char id[20];
    double x;
    char tipo;
    int z;
} Obstaculo;

typedef struct {
    double tiempo;
    char personaje[20];
    int z;
    bool ejecutado;
} Movimiento;

//Lee el archivo de entidades y los carga.
int cargarEntidades(char *argv[], Obstaculo *obstaculos, Personaje *personajes) {
    FILE *archivo_entidades = fopen(argv[1], "r");

    if (!archivo_entidades) {
        fprintf(stderr, "Error, no se puede abrir el archivo de entidades\n");
        return -1;
    }

    char linea[128];

    while (fgets(linea, sizeof(linea), archivo_entidades) && cantidad_entidades < MAX_ENTIDAD) {

        char id[20];
        double x;
        char tipo;
        int z;

        sscanf(linea, "%[^,], %lf, %c, %d", id, &x, &tipo, &z);
        if (tipo == OBSTACULO) {
            strcpy(obstaculos[cantidad_obstaculos].id, id);
            obstaculos[cantidad_obstaculos].x = x;
            obstaculos[cantidad_obstaculos].tipo = tipo;
            obstaculos[cantidad_obstaculos].z = z;
            cantidad_obstaculos++;
            if(x_ultimo_obstaculo < x){
                x_ultimo_obstaculo = x;
            }
        } else {
            strcpy(personajes[cantidad_personajes].id, id);
            personajes[cantidad_personajes].x = x;
            personajes[cantidad_personajes].tipo = tipo;
            personajes[cantidad_personajes].z = z;
            personajes[cantidad_personajes].eliminado = false;
            personajes[cantidad_personajes].tiempo = 0;
            cantidad_personajes++;
        }
        cantidad_entidades++;
    }

    fclose(archivo_entidades);
    return cantidad_entidades;
}

//Lee el archivo de movimientos y los carga.
int cargarMovimientos(char *argv[], Movimiento* movimientos) {
    FILE *archivo_movimientos = fopen(argv[2], "r");

    if (!archivo_movimientos) {
        fprintf(stderr, "Error, no se puede abrir el archivo de movimientos\n");
        return -1;
    }

    char linea[128];
    while (fgets(linea, sizeof(linea), archivo_movimientos) && cantidad_movimientos < MAX_ENTIDAD) {


        sscanf(linea, "%lf, %[^,], %d\n",&movimientos[cantidad_movimientos].tiempo, movimientos[cantidad_movimientos].personaje, &movimientos[cantidad_movimientos].z);
        movimientos[cantidad_movimientos].ejecutado = false;
        cantidad_movimientos++;
    }
    return cantidad_movimientos;
}

//verifica los parámetros de entrada del programa
int verificarArgumentos(int argc) {
    if (argc == 3) {
        return 0;
    }
    fprintf(stderr, "%s\n", "Error: Numero de parametros incorrecto. Se necesitan 2 archivos");
    return -1;
}

bool continuar (Personaje *personajes){
    for(int i = 0; i < cantidad_personajes; i++){
        if((!personajes[i].eliminado) && personajes[i].x < x_ultimo_obstaculo){
            return true;
        }
    }
    return false;
}

void ejecutarMovimiento(Movimiento* movimientos,Personaje *personajes){
    for(int i = 0; i < cantidad_personajes; i++){
        if(personajes[i].eliminado || personajes[i].x > x_ultimo_obstaculo){
            continue;
        }
        for (int j = 0; j < cantidad_movimientos; j++) {
            if((!movimientos[j].ejecutado) && strcmp( movimientos[j].personaje,personajes[i].id) == 0 && personajes[i].tiempo >=  movimientos[j].tiempo){
                personajes[i].z =  movimientos[j].z;
                movimientos[j].ejecutado = true;
            }
        }
        personajes[i].tiempo += ERROR;
        personajes[i].x += ERROR;
    }
}

void verificarColision(Obstaculo *obstaculos, Personaje *personajes){
    for(int i = 0; i < cantidad_personajes; i++){
        if(personajes[i].eliminado){
            continue;
        }
        for(int j = 0; j < cantidad_obstaculos; j++){
            if(personajes[i].z ==  obstaculos[j].z &&  (fabs(obstaculos[j].x - personajes[i].x) <= ERROR) && (personajes[i].x > obstaculos[j].x)){
                personajes[i].eliminado = true;
                fprintf(stdout,"Personaje: %s recorrio: %lf\n",personajes[i].id,personajes[i].tiempo);
            }
        }
    }
}

int ejecutar(Obstaculo *obstaculos, Personaje *personajes, Movimiento* movimientos){

    while(continuar(personajes)){
        ejecutarMovimiento(movimientos,personajes);
        verificarColision(obstaculos,personajes);
    }
    return 0;
}

int main(int argc, char *argv[]) {
    int r = verificarArgumentos(argc);
    if (r < 0) {
        return -r;
    }

    Obstaculo obstaculos[MAX_ENTIDAD];
    Personaje personajes[MAX_ENTIDAD];
    Movimiento movimientos[MAX_ENTIDAD];
    int res;

    res = cargarEntidades(argv, obstaculos,personajes);
    if (res < 0) {
        return -r;
    }

    res = cargarMovimientos(argv, movimientos);
    if (res < 0) {
        return -r;
    }

    res = ejecutar(obstaculos,personajes,movimientos);
    if(res < 0){
        return -r;
    }
    return 0;
}



