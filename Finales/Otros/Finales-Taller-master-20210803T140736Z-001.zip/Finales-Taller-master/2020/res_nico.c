#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX_ID 64
#define MAX_PERS 64
#define MAX_OBST 64
#define MAX_ACC 64
#define VEL_PER 1
#define PASO 0.01/VEL_PER
#define OBSTACULO 'o'

typedef struct {
	double x;
	int z;
	char id[MAX_ID];
	bool choco;
} personaje_t;

typedef struct {
	double x;
	int z;
} obstaculo_t;

typedef struct {
	double tiempo;
	int z;
	char id[MAX_ID];
} accion_t;

int leer_pers_y_obst(personaje_t *pers, int *cant_pers, obstaculo_t *obst, int *cant_obst) {
	FILE *archivo = fopen("entidades.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro entidades.txt\n");
		return -1;
	}
	*cant_pers = 0;
	*cant_obst = 0;
	int res_leer_linea = 1;
	char tipo;
	while (res_leer_linea != EOF) {
		res_leer_linea = fscanf(archivo, "%[^,], %lf, %c, %d\n", pers[*cant_pers].id, &(pers[*cant_pers].x), &tipo, &(pers[*cant_pers].z));
		if (res_leer_linea != EOF) {
			if (tolower(tipo) == OBSTACULO) {
				obst[*cant_obst].x = pers[*cant_pers].x;
				obst[*cant_obst].z = pers[*cant_pers].z;
				*cant_obst += 1;
			} else {
				pers[*cant_pers].choco = false;
				*cant_pers += 1;
			}
		}
	}

	fclose(archivo);
	return 0;
}

int leer_acciones(accion_t *acciones) {
	FILE *archivo = fopen("acciones.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro acciones.txt\n");
		return -1;
	}
	int cant_acc = 0;
	int res_leer_linea = 1;
	while (res_leer_linea != EOF) {
		res_leer_linea = fscanf(archivo, "%lf, %[^,], %d\n", &(acciones[cant_acc].tiempo), acciones[cant_acc].id, &(acciones[cant_acc].z));
		if (res_leer_linea != EOF)
			cant_acc += 1;
	}	

	fclose(archivo);
	return cant_acc;
}

int comparar_obstaculos(const void *o1, const void *o2) {
	return (int)( ((obstaculo_t *)o1)->x > ((obstaculo_t *)o2)->x );
}

void verificar_accion(personaje_t *per, accion_t *acciones, int cant_acc, double tiempo) {
	int acc_itr = 0;
	bool hubo_accion = false;
	while (!hubo_accion && acc_itr < cant_acc) {
		if (strcmp(per->id, acciones[acc_itr].id) == 0 && tiempo < acciones[acc_itr].tiempo && tiempo + PASO >= acciones[acc_itr].tiempo) {
			per->z = acciones[acc_itr].z;
			hubo_accion = true;
		}
		++acc_itr;
	}
}

bool verificar_colision(personaje_t *per, obstaculo_t *obst, int cant_obst) {
	int itr = 0;
	while (!per->choco && itr < cant_obst) {
		if (per->z == obst[itr].z && per->x < obst[itr].x && per->x + VEL_PER*PASO >= obst[itr].x) {
			per->choco = true;
		}
		++itr;
	}
	return per->choco;
}

bool iterar(personaje_t *pers, int cant_pers, obstaculo_t *obst, int cant_obst, accion_t *acciones, int cant_acc, double tiempo) {
	bool seguir_iterando = false;
	bool hubo_choque;
	double max_x = obst[cant_obst - 1].x;
	for (int i = 0; i < cant_pers; ++i) {
		if (pers[i].choco)
			continue;

		verificar_accion(&pers[i], acciones, cant_acc, tiempo);
		hubo_choque = verificar_colision(&pers[i], obst, cant_obst);
		if (!hubo_choque) {
			pers[i].x += VEL_PER*PASO;
			seguir_iterando |= pers[i].x < max_x;			
		} else {
			printf("Choco %s y recorrio %lf\n", pers[i].id, tiempo * VEL_PER);
		}
	}

	return seguir_iterando;
}

void procesar(personaje_t *pers, int cant_pers, obstaculo_t *obst, int cant_obst, accion_t *acciones, int cant_acc) {
	double tiempo = 0.0f;
	bool seguir_iterando = true;
	while(seguir_iterando) {
		seguir_iterando = iterar(pers, cant_pers, obst, cant_obst, acciones, cant_acc, tiempo);
		tiempo += PASO;
	}
}

int main(void) {
	int cant_pers = 0;
	int cant_obst = 0;
	personaje_t pers[MAX_PERS];
	obstaculo_t obst[MAX_OBST];
	if (leer_pers_y_obst(pers, &cant_pers, obst, &cant_obst) < 0)
		return 1;
	for (int i = 0; i < cant_pers; ++i) {
		printf("lei %s, posx: %lf, z: %d\n", pers[i].id, pers[i].x, pers[i].z);
	}
	for (int i = 0; i < cant_obst; ++i) {
		printf("lei obst posx: %lf, z: %d\n", obst[i].x, obst[i].z);
	}
	accion_t acciones[MAX_ACC];
	int cant_acc = leer_acciones(acciones);
	if (cant_acc < 0)
		return 1;
	for (int i = 0; i < cant_acc; ++i) {
		printf("lei acc id: %s, tiempo: %lf, z: %d\n", acciones[i].id, acciones[i].tiempo, acciones[i].z);
	}

	qsort(obst, cant_obst, sizeof(obstaculo_t), comparar_obstaculos);
	
	procesar(pers, cant_pers, obst, cant_obst, acciones, cant_acc);
	return 0;
}
