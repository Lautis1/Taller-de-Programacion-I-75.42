#include <stdio.h>
#include <stdbool.h>
#include <string.h>

/*
 2        O1
 1               P2
 0 P1
   0  2  4  6  8  10  12  14  16  18  20

  */

#define MAX_CHAR 30
#define MAX_ENT 100
#define MAX_LINEA 256

const double VEL_P = 1;
const double DISCRET = 1000;
const double PRES = VEL_P/DISCRET;
const char OBSTACULO = 'O';

int c_p = 0;
int c_o = 0;
int c_d = 0;
int max_x_obst = -1;
double tiempo = 0;

typedef struct entidad{
    char id[MAX_CHAR];
    double x;
    double x0;
    int z;
    bool colisiono;
    double distancia;
} entidad_t;

typedef struct desp{
    char id_p[MAX_CHAR];
    double momento_x;
    int z;
    bool hecho;
} desp_t;

void cargar_entidades(entidad_t* personajes, entidad_t* obstaculos){
    char linea[MAX_LINEA];
    FILE* archivo = fopen("entidades.txt", "r");

    if(!archivo){
        return;
    }

    for(int i = 0; fgets(linea, sizeof(linea), archivo); i +=1 ){
        char id_aux[MAX_CHAR];
        double x_aux;
        int z_aux;
        char tipo_aux;
        sscanf(linea, "%[^,],%lf,%c,%d", id_aux, &x_aux, &tipo_aux, &z_aux);

        if(tipo_aux == OBSTACULO){
            strcpy(obstaculos[c_o].id, id_aux);
            obstaculos[c_o].x = x_aux;
            obstaculos[c_o].x0 = x_aux;
            obstaculos[c_o].z = z_aux;
            obstaculos[c_o].distancia = 0;
            obstaculos[c_o].colisiono = false;

            if(obstaculos[c_o].x > max_x_obst){
                max_x_obst = obstaculos[c_o].x;
            }

            c_o += 1;
        }
        else{
            strcpy(personajes[c_p].id, id_aux);
            personajes[c_p].x = x_aux;
            personajes[c_p].z = z_aux;
            personajes[c_p].x0 = x_aux;
            personajes[c_p].distancia = 0;
            personajes[c_p].colisiono = false;
            c_p += 1;
        }
    }

    fclose(archivo);
}

void cargar_desplazamientos(desp_t* desplazamientos){
    char linea[MAX_LINEA];
    FILE* archivo = fopen("desplazamientos.txt", "r");

    if(!archivo){
        return;
    }

    for(int i = 0; fgets(linea, sizeof(linea), archivo); i +=1 ){
        sscanf(linea, "%lf,%[^,],%d", &desplazamientos[i].momento_x, desplazamientos[i].id_p, &desplazamientos[i].z);
        desplazamientos[i].hecho = false;
        c_d += 1;
    }

    fclose(archivo);
}

void mostrar(entidad_t* personajes, entidad_t* obstaculos, desp_t* desp){
    for(int i = 0; i < c_p; i += 1){
        printf("%s %lf %d \n", personajes[i].id, personajes[i].x, personajes[i].z);
    }
    printf("======1===== \n");
    for(int i = 0; i < c_o; i += 1){

        printf("%s %lf %d \n", obstaculos[i].id, obstaculos[i].x, obstaculos[i].z);
    }

    printf("=====2====== \n");
    for(int i = 0; i < c_d; i += 1){

        printf("%s %lf %d \n", desp[i].id_p, desp[i].momento_x, desp[i].z);
    }
}

void mostrar_muertos(entidad_t* personajes){
    for(int i = 0; i < c_p; i += 1){
        if( personajes[i].colisiono ){
            printf("%s %lf \n", personajes[i].id, personajes[i].distancia);
        }
    }
}

bool hay_obstaculos(entidad_t* personajes){
    for(int i = 0; i < c_p; i += 1) {
        if( (personajes[i].x < max_x_obst) && (!personajes[i].colisiono) ){
            return true;
        }
    }
    return false;
}

bool hay_colision(entidad_t* p, entidad_t* o){
    if( (p->colisiono) || (p->z != o->z) ){
        return false;
    }

    return ( (p->x + PRES) >= o->x ) && ( (p->x0 + PRES) < o->x );
}

void ver_cambio(entidad_t* p,  desp_t* desp ){
    for(int i = 0; i < c_d; i += 1) {
        // VEL * TIEMPO = DISTANCIA: el valor que dan es un X
        if( ( !desp[i].hecho ) && ( strcmp(desp[i].id_p, p->id) == 0 ) && ( (tiempo + PRES) >= desp[i].momento_x ) ){
            desp[i].hecho = true;
            p->z = desp[i].z;
        }
    }
}

void mover(entidad_t* p){
    if(p->colisiono){
        return;
    }

    p->x += VEL_P/DISCRET;
    p->distancia += VEL_P/DISCRET;
}

void actualizar(entidad_t* personajes, entidad_t* obstaculos, desp_t* desp){
    while( hay_obstaculos(personajes) ){
        // ver colisiones
        for(int i = 0; i < c_p; i += 1){
            for(int j = 0; j < c_o; j += 1){
                if( hay_colision(&personajes[i], &obstaculos[j]) ){
                    personajes[i].colisiono = true;
                }
            }
        }

        // ver cambios
        for(int i = 0; i < c_p; i += 1) {
            ver_cambio(&personajes[i], desp);
            mover(&personajes[i]);
        }

        // avanzar tiempo
        tiempo += VEL_P/DISCRET;
        //printf("%lf ", tiempo);
    }
}

int main() {
    entidad_t personajes[MAX_ENT];
    entidad_t obstaculos[MAX_ENT];
    desp_t desplazamientos[MAX_ENT];

    cargar_entidades(personajes, obstaculos);
    cargar_desplazamientos(desplazamientos);

    if( (c_p < 1) || (c_d < 1) ){
        printf("Faltan personajes o desplazamientos. \n");
        return 1;
    }

    //mostrar(personajes, obstaculos, desplazamientos);
    actualizar(personajes, obstaculos, desplazamientos);
    mostrar_muertos(personajes);
    return 0;
}
