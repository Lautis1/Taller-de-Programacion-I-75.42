#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_ATAQ 20
#define VIDA_P 100.0
#define PASO 0.001
#define SALTO 5.0
#define AGACHE 10.0

typedef struct Personaje{
	float xpi;
	float xpd;
	float ypi;
	float ypd;
	float vida;
} personaje_t;

typedef struct Ataque{
	char id_ataque[20];
	float xii;
	float yii;
	float xsd;
	float ysd;
	float energia;
	float distancia;
	bool termino;
	char accion;

} ataque_t;

static int cant_ataques = 0;

void iniciarPersonaje(personaje_t *personaje,char *nombre_archivo);
void iniciarAtaques(personaje_t personaje,ataque_t *ataques,char *nombre_archivo);
void actualizar(personaje_t *personaje,ataque_t *ataques);
bool seguir(ataque_t *ataques);
void mover(personaje_t personaje,ataque_t *ataques);
void colisionar(personaje_t *personaje,ataque_t *ataques);
void accionar(personaje_t *personaje,ataque_t ataque);
bool hayColision(personaje_t p,ataque_t a);
bool colisionABAI(personaje_t p,ataque_t a);
bool colisionARRI(personaje_t p,ataque_t a);

int main(int argc,char *argv[]){

	personaje_t personaje;
	ataque_t ataques[MAX_ATAQ];

	iniciarPersonaje(&personaje,argv[1]);

	iniciarAtaques(personaje,ataques,argv[2]);

	actualizar(&personaje,ataques);

	return 0;
}

void iniciarPersonaje(personaje_t *personaje,char *nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");

	if ( archivo == NULL ){
		printf("%s\n","No se pude abrir el archivo de personajes." );
		exit(1);
	}

	char linea[256];
	fgets(linea,sizeof(linea),archivo);
	sscanf(linea,"%f %f %f",&personaje->xpi,&personaje->xpd,&personaje->ypd);
	personaje->vida = VIDA_P;
	personaje->ypi = 0.0;
	fclose(archivo);
}

void iniciarAtaques(personaje_t personaje,ataque_t *ataques,char *nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");

	if ( archivo == NULL ){
		printf("%s\n","No se pude abrir el archivo de ataques." );
		exit(1);
	}

	char linea[256];

	while( fgets(linea,sizeof(linea),archivo) ) {
		sscanf(linea,"%s %f %f %f %f %f %c\n",ataques[cant_ataques].id_ataque,&ataques[cant_ataques].xii,&ataques[cant_ataques].yii,&ataques[cant_ataques].xsd,&ataques[cant_ataques].ysd,&ataques[cant_ataques].energia,&ataques[cant_ataques].accion);

		ataques[cant_ataques].distancia = 0.0;
		ataques[cant_ataques].termino = ( (personaje.xpd < ataques[cant_ataques].xii ) || ( personaje.ypd < ataques[cant_ataques].yii ));

		if ( ataques[cant_ataques].termino ){
			printf("ID_ATAQUE: %s; No colisiona\n",ataques[cant_ataques].id_ataque);
		}
		cant_ataques++;
	}
	fclose(archivo);
}

void actualizar(personaje_t *personaje,ataque_t *ataques){

	while ( seguir(ataques) ){
		colisionar(personaje,ataques);
		mover(*personaje,ataques);
	}
}

bool seguir(ataque_t *ataques){

	for ( int i = 0; i<cant_ataques;i++ ){
		if( ! ataques[i].termino ){
			return true;
		}
	}
	return false;
}

void mover(personaje_t personaje,ataque_t *ataques){

	for(int i = 0; i<cant_ataques;i++){

		if ( ataques[i].termino ){
			continue;
		}
		ataques[i].xii += PASO;
		ataques[i].xsd += PASO;
		ataques[i].distancia += PASO;
		ataques[i].termino = ( personaje.xpd < ataques[i].xii );

		if ( ataques[i].termino ){
			printf("ID_ATAQUE: %s; No colisiona\n",ataques[i].id_ataque);
		}
	}
}

void colisionar(personaje_t *personaje,ataque_t *ataques){

	for(int i = 0; i<cant_ataques;i++){
		if( ataques[i].termino ){
			continue;
		}

		if( hayColision(*personaje,ataques[i])){
			personaje_t personaje_aux;

			personaje_aux.xpi = personaje->xpi;
			personaje_aux.xpd = personaje->xpd;
			personaje_aux.ypi = personaje->ypi;
			personaje_aux.ypd = personaje->ypd;

			accionar(&personaje_aux,ataques[i]);
						
			if ( hayColision(personaje_aux,ataques[i]) && ( personaje->vida > 0.0 )){
				personaje->vida -= ataques[i].energia;
				if ( personaje->vida  <= 0 ) personaje->vida = 0;
				printf("ID_ATAQUE: %s;DISTANCIA: %f;ENERGIA RESTANTE: %f\n",ataques[i].id_ataque,ataques[i].distancia,personaje->vida );
			}
			else{
				printf("ID_ATAQUE: %s; No colisiona\n",ataques[i].id_ataque );
			}

			ataques[i].termino = true;
		}
	}
}

void accionar(personaje_t *personaje,ataque_t ataque){

	switch ( ataque.accion ){
		case 'N':{
			return;
		}
		case 'S':{
			personaje->ypi = personaje->ypi + SALTO;
			personaje->ypd = personaje->ypd + SALTO;
			break;
		}
		case 'A':{
			personaje->ypd = personaje->ypd - AGACHE;
			break;
		}
		case 'C':{
			personaje->ypi = personaje->ypi + SALTO;
			personaje->ypd = personaje->ypd + SALTO;
			personaje->ypd = personaje->ypd - AGACHE;
			break;
		}
	}
}

bool hayColision(personaje_t personaje,ataque_t ataque){
	return ( colisionABAI(personaje,ataque) || colisionARRI(personaje,ataque) );
}

bool colisionABAI(personaje_t p,ataque_t a){
	return ( ( p.xpi <= a.xsd ) && ( a.xsd <= p.xpd ) && ( p.ypi <= a.ysd ) && ( a.ysd <= p.ypd ) );
}

bool colisionARRI(personaje_t p,ataque_t a){
	return ( ( p.xpi <= a.xsd ) && ( a.xsd <= p.xpd ) && ( p.ypi <= a.yii ) && ( a.yii <= p.ypd ) );
}