#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define MAX_ID 64
#define MAX_BORDE 10
#define MAX_BALAS 64

typedef enum { 
	BORDE_SUP,
	BORDE_1,
	BORDE_2,
	BORDE_3,
	BORDE_INF
} bordes_t;

typedef struct {
	char id[MAX_ID];
	double xo;
	double yo;
	double xd;
	double yd;
	double distancia;
	bordes_t destino;
} bala_t;

/*
	Sean los puntos (u,v) y (w,z), la forma de obtener los coeficientes de la recta y=mx+b es:
	b=v-mu, m = (z-v) / (w-u)

	Luego para la interseccion entre dos rectas, sean y=m1x+b1 y y=m2x+b2 es: m1x+b1 = m2x+b2 =>
	m1x-m2x = b2-b1 => x = (b2-b1) / (m1-m2)

	Luego las rectas son: 
	 -borde_sup: y=0x+60
	 -borde_1: (60, 60), (65, 40) -> y=-4x+300
	 -borde_2: x=65
	 -borde_3: (60, 0), (65, 20) ->  y=4x-240
	 -borde_inf: y=0x+0
*/

//HIPOTESIS: la direccion de la recta tiene siempre x positiva, es decir bala->xo < bala->xd

//Devuelve -1 en caso de error o sino la cantidad de balas que pudo leer del archivo de texto balas.txt
int leer_balas(bala_t* balas) {
	FILE* archivo = fopen("balas.txt", "r");
	if (!archivo) {
		fprintf(stderr, "No se encontro el archivo 'balas.txt'");
		return -1;
	}
	int cant_balas = 0;
	int res_leer_linea = 1;
	while (res_leer_linea != EOF && cant_balas < MAX_BALAS) { 
		res_leer_linea = fscanf(archivo, "%s %lf %lf %lf %lf", balas[cant_balas].id, &(balas[cant_balas].xo), &(balas[cant_balas].yo), &(balas[cant_balas].xd), &(balas[cant_balas].yd));
		if (res_leer_linea != EOF && balas[cant_balas].xo < balas[cant_balas].xd) {
			balas[cant_balas].distancia = 0;
			balas[cant_balas].destino = 0;
			cant_balas += 1;
		}
	}

	fclose(archivo);
	return cant_balas;
}

double calcular_distancia(double x1, double y1, double x2, double y2) {
	return sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
}

double calcular_x_interserccion(double m1, double b1, double m2, double b2) {
	return (b2-b1) / (m1-m2);
}

void calcular_distancia_borde_sup(bala_t* bala, double m1, double b1) {
	//Busco el punto de interseccion con el borde superior y calculo la distancia a ese punto
	double m2 = 0;
	double b2 = 60;
	double x_intersec = calcular_x_interserccion(m1, b1, m2, b2);
	printf("borde_sup: %s choca en x: %lf, y: %lf\n", bala->id, x_intersec, 60.0f);
	bala->distancia = calcular_distancia(bala->xo, bala->yo, x_intersec, 60);
}

void calcular_distancia_borde_inf(bala_t* bala, double m1, double b1) {	
	//Busco el punto de interseccion con el borde inferior y calculo la distancia a ese punto
	double m2 = 0;
	double b2 = 0;
	double x_intersec = calcular_x_interserccion(m1, b1, m2, b2);
	printf("borde_inf: %s choca en x: %lf, y: %lf\n", bala->id, x_intersec, 0.0f);
	bala->distancia = calcular_distancia(bala->xo, bala->yo, x_intersec, 0);

}

void calcular_distancia_borde_1(bala_t* bala, double m1, double b1) {
	//Busco el punto de interseccion con el borde 1 y calculo la distancia a ese punto
	double m2 = -4;
	double b2 = 300;
	double x_intersec = calcular_x_interserccion(m1, b1, m2, b2);
	double y_intersec = m2*x_intersec + b2;
	printf("borde_1: %s choca en x: %lf, y: %lf\n", bala->id, x_intersec, y_intersec);
	bala->distancia = calcular_distancia(bala->xo, bala->yo, x_intersec, y_intersec);
}

void calcular_distancia_borde_2(bala_t* bala, double m1, double b1) {
	//Busco el punto de interseccion con el borde 2 y calculo la distancia a ese punto
	double y_intersec = m1*65+b1;
	printf("borde_2: %s choca en x: %lf, y: %lf\n", bala->id, 65.0f, y_intersec);
	bala->distancia = calcular_distancia(bala->xo, bala->yo, 65, y_intersec);
}

void calcular_distancia_borde_3(bala_t* bala, double m1, double b1) {
	//Busco el punto de interseccion con el borde 3 y calculo la distancia a ese punto
	double m2 = 4;
	double b2 = -240;
	double x_intersec = calcular_x_interserccion(m1, b1, m2, b2);
	double y_intersec = m2*x_intersec + b2;
	printf("borde_3: %s choca en x: %lf, y: %lf\n", bala->id, x_intersec, y_intersec);
	bala->distancia = calcular_distancia(bala->xo, bala->yo, x_intersec, y_intersec);
}

//La idea consiste en obtener una funcion de la forma y = mx+b y ver a que valor de Y llego con
//x=65 y cual era el valor de Y en x=60, dada la hipotesis de que x_i > x_o
void procesar_bala(bala_t* bala) {
	//Busco la recta y=mx+b que sigue la trayectoria de la bala
	double m = (bala->yd - bala->yo) / (bala->xd - bala->xo);
	double b = bala->yo - (m * bala->xo);
	//Si la posicion x inicial es menor a 60 y por hipotesis la x destino es mayor que x origen, verifico si en x=60 ya pase por bordes sup o inf
	double y_60 = m*60 + b;
	if (bala->xo < 60 && y_60 > 60) {
		bala->destino = BORDE_SUP;
		calcular_distancia_borde_sup(bala, m, b);
	} else if (bala->xo < 60 && y_60 < 0) {
		bala->destino = BORDE_INF;
		calcular_distancia_borde_inf(bala, m, b);
	} else {
		//Como no pase por borde sup o inf, tengo que haber chocado con alguno de los otros 3 bordes
		//Verifico en que lugar estoy en x=65 y defino en base a eso
		double y_65 = m*65 + b;
		if (y_65 > 40) {
			bala->destino = BORDE_1;
			calcular_distancia_borde_1(bala, m, b);
		} else if (y_65 < 20) {
			bala->destino = BORDE_3;
			calcular_distancia_borde_3(bala, m, b);
		} else {
			bala->destino = BORDE_2;
			calcular_distancia_borde_2(bala, m, b);
		}
	}
}

void procesar(bala_t* balas, int cant_balas) {
	for (int i = 0; i < cant_balas; ++i) {
		procesar_bala(&balas[i]);
	}
}

int comparar(const void* bala_1, const void* bala_2) {
	bala_t* b1 = (bala_t*) bala_1;
	bala_t* b2 = (bala_t*) bala_2;
	return (int)(b1->distancia > b2->distancia);
}

void imprimir_resultado(bala_t* balas, int cant_balas) {
	qsort(balas, cant_balas, sizeof(bala_t), comparar);
	char destinos[5][MAX_BORDE] = {"Borde_sup", "Borde_1", "Borde_2", "Borde_3", "Borde_Inf"};
	for (int i = 0; i < cant_balas; ++i) {
		fprintf(stdout, "Recorrio una distancia %lf con id %s y su destino es %s\n", balas[i].distancia, balas[i].id, destinos[balas[i].destino]);
	}
}

int main(void) {
	bala_t balas[MAX_BALAS];
	int cant_balas = leer_balas(balas);
	if (cant_balas < 0)
		return -1;
	for (int i = 0; i < cant_balas; ++i) {
		printf("%s con pos inicial x: %.2lf, y: %.2lf, dir x: %.2lf, y: %.2lf\n", balas[i].id, balas[i].xo, balas[i].yo, balas[i].xd, balas[i].yd);
	}
	printf("\nFin lectura\n\n");
	procesar(balas, cant_balas);
	printf("\nFin procesamiento\n\n");
	imprimir_resultado(balas, cant_balas);
	return 0;
}
