#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<math.h>


#define MAX_CANT_BALAS 20
#define BORDE_SUPERIOR 60.0
#define BORDE_INFERIOR 0.0
#define BORDE_DOS 65.0
#define BORDE_UNO_TRES 60.0
#define DESTINO 100.0
#define YD1 40.0
#define YO1 60.0
#define YD3 20.0
#define YO3 0.0
#define MAX_DISTANCIA 92.0
#define PENIENTE_TRES (YD3-YO3)/(BORDE_DOS-BORDE_UNO_TRES)
#define PENIENTE_UNO (YD1-YO1)/(BORDE_DOS-BORDE_UNO_TRES)


typedef struct{
	char id_recorrido[20];
	double xo;
	double yo;
	double xd;
	double yd;
	double pendiente;
	double distancia;
	char id_destino[20];
} Bala;

typedef struct{
	double distancia;
	char id_destino[20];
}Resultado_aux;

void InicializarBalas(Bala *balas,char* nombre_archivo);
void calcularDistancias(Bala *balas);
void calcularDistanciaBS(Bala bala,Resultado_aux *aux);
void calcularDistanciaBI(Bala bala,Resultado_aux *aux);
void calcularDistanciaB1(Bala bala,Resultado_aux *aux);
void calcularDistanciaB2(Bala bala,Resultado_aux *aux);
void calcularDistanciaB3(Bala bala,Resultado_aux *aux);
int definirDistancia(Resultado_aux *distancias);
void mostrar(Bala *balas);
int comparar(const void* a, const void* b);

static int cant_balas = 0;

int main(int argc,char* argv[]){
	if ( argc != 2 ){
		printf("%s\n", "No se ingreso la cantidad de argumentos que se necesita.");
		exit(1);
	}
	Bala balas[MAX_CANT_BALAS];

	//Inicializar las balas:
	InicializarBalas(balas,argv[1]);

	//Calculo la distancia para cada bala:
	calcularDistancias(balas);

	//Mostrar resultados:
	mostrar(balas);

	return 0;
}

void InicializarBalas(Bala *balas,char* nombre_archivo){

	FILE* archivo = fopen(nombre_archivo,"r");
	char linea[256];

	if ( archivo == NULL ){
		printf("No se pudo abrir el archivo%s\n",nombre_archivo );
		exit(1);
	}

	while ( fgets(linea,sizeof(linea),archivo) ){

		sscanf(linea,"%s %lf %lf %lf %lf",balas[cant_balas].id_recorrido,&balas[cant_balas].xo,&balas[cant_balas].yo,&balas[cant_balas].xd,&balas[cant_balas].yd);
		strcpy(balas[cant_balas].id_destino,"");

		if ( balas[cant_balas].xd == balas[cant_balas].xo ){
			balas[cant_balas].pendiente = 0.0;
			if ( balas[cant_balas].yd >= balas[cant_balas].yo ){
				balas[cant_balas].yd = DESTINO;
			}
			else{
				balas[cant_balas].yd = (-1) *DESTINO;
			}
		}
		else{
			double dY = balas[cant_balas].yd - balas[cant_balas].yo;
			double dX = balas[cant_balas].xd - balas[cant_balas].xo;

			balas[cant_balas].pendiente = ( dY / dX );

			balas[cant_balas].xd = DESTINO;
			balas[cant_balas].yd = ( DESTINO - balas[cant_balas].xo ) * balas[cant_balas].pendiente + balas[cant_balas].yo;
		} 

		balas[cant_balas].distancia = 0.0;
		cant_balas++;
	}

	fclose(archivo);
}


void calcularDistancias(Bala *balas){

	Resultado_aux distancias[5];

	int pos = -1;

	for (int i = 0; i<cant_balas;i++){

		calcularDistanciaBS(balas[i],&distancias[0]);
		calcularDistanciaBI(balas[i],&distancias[1]);
		calcularDistanciaB1(balas[i],&distancias[2]);
		calcularDistanciaB2(balas[i],&distancias[3]);
		calcularDistanciaB3(balas[i],&distancias[4]);

		pos = definirDistancia(distancias);

		balas[i].distancia = distancias[pos].distancia;
		strcpy(balas[i].id_destino,distancias[pos].id_destino);
	}
}

int definirDistancia(Resultado_aux *distancias){

	double dist = MAX_DISTANCIA;
	int pos = -1;
	for(int i = 0; i < 5; i++){
		if ( distancias[i].distancia < dist ){
			dist = distancias[i].distancia;
			pos = i;
		}
	}
	return pos;
}


void calcularDistanciaBS(Bala bala,Resultado_aux *aux){

	strcpy(aux->id_destino,"Borde_Sup");

	if ( bala.yd < BORDE_SUPERIOR ){
		aux->distancia = MAX_DISTANCIA;
		return ;
	}

	if ( bala.pendiente == 0 ){
		aux->distancia = BORDE_SUPERIOR - bala.yo;
		return ;
	}

	double yd = BORDE_SUPERIOR;
	double xd = ( BORDE_SUPERIOR - bala.yo ) / bala.pendiente  + bala.xo;
	double distancia = sqrt( pow(yd - bala.yo,2) + pow(xd - bala.xo,2) );

	aux->distancia = distancia;
	
}

void calcularDistanciaBI(Bala bala,Resultado_aux *aux){

	strcpy(aux->id_destino,"Borde_Inf");

	if ( bala.yd >  BORDE_INFERIOR ){
		aux->distancia = MAX_DISTANCIA;
		return ;
	}

	if ( bala.pendiente == 0 ){
		aux->distancia = bala.yo;
		return ;
	}

	double yd = BORDE_INFERIOR;
	double xd = ( BORDE_INFERIOR - bala.yo ) / bala.pendiente  + bala.xo;
	double distancia = sqrt( pow(yd - bala.yo,2) + pow(xd - bala.xo,2) );


	aux->distancia = distancia;

}

void calcularDistanciaB2(Bala bala,Resultado_aux *aux){

	strcpy(aux->id_destino,"Borde_Dos");

	if ( bala.xd <  BORDE_DOS ){
		aux->distancia = MAX_DISTANCIA;
		return;
	}

	if ( bala.pendiente == 0 ){
		aux->distancia = BORDE_DOS - bala.xo ;
		return;
	}

	double xd = BORDE_DOS;
	double yd = ( BORDE_DOS - bala.xo ) * bala.pendiente  + bala.yo;
	double distancia = sqrt( pow(yd - bala.yo,2) + pow(xd - bala.xo,2) );

	aux->distancia = distancia ;
}

void calcularDistanciaB1(Bala bala,Resultado_aux *aux){

	strcpy(aux->id_destino,"Borde_Uno");

	if ( bala.xd <  BORDE_UNO_TRES && bala.yd < 40.0 ){
		aux->distancia = MAX_DISTANCIA;
		return ;
	}

	double xd = ( YO1 - bala.yo - ( BORDE_UNO_TRES * PENIENTE_UNO - bala.xo * bala.pendiente ) ) / ( bala.pendiente - PENIENTE_UNO );
	double yd = PENIENTE_UNO * ( xd - BORDE_UNO_TRES ) + YO1;
	double distancia = sqrt( pow(yd - bala.yo,2) + pow(xd - bala.xo,2) );

	if (( YD1 <= yd ) && ( yd <= BORDE_SUPERIOR )){
		aux->distancia = distancia;
	}
	else{
		aux->distancia = MAX_DISTANCIA;
	}
}

void calcularDistanciaB3(Bala bala,Resultado_aux *aux){

	strcpy(aux->id_destino,"Borde_Tres");

	if ( bala.xd <  BORDE_UNO_TRES  && bala.yd > 20.0  ){
		aux->distancia = MAX_DISTANCIA;
		return;
	}


	double xd = ( YO3 - bala.yo - ( BORDE_UNO_TRES * PENIENTE_TRES - bala.xo * bala.pendiente ) ) / ( bala.pendiente - PENIENTE_TRES );
	double yd = PENIENTE_TRES * ( xd - BORDE_UNO_TRES ) + YO3;
	double distancia = sqrt( pow(yd - bala.yo,2) + pow(xd - bala.xo,2) );

	if (( YO3 <= yd ) && ( yd <= YD3 )){
		aux->distancia = distancia;
	}
	else{
		aux->distancia = MAX_DISTANCIA;
	}
}

int comparar(const void* a, const void* b){

	Bala* b1 = (Bala*) a;
	Bala* b2 = (Bala*) b;

	return (int) (b1->distancia > b2->distancia);
}

void mostrar(Bala *balas){

	qsort(balas,cant_balas,sizeof(Bala),comparar);

	for( int i = 0; i<cant_balas;i++){

		printf("LONGITUD_RECORRIDO: %lf;ID_RECORRIDO: %s;DESTINO: %s\n",balas[i].distancia,balas[i].id_recorrido,balas[i].id_destino);
	}
}