//1000 actualizaciones por segundo

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define VEL_MOSCA 10
#define MAX_ID 32
#define N_PER 8
#define N_MOS 25
#define LADO_MOSCA 1

static double MAX_DIVISION = 1.0f;
static double MAX_VEL = 0.0f;

typedef struct {
	char id[MAX_ID];
	double x_i;
	double x_d;
	double y_d;
	double vel;
	int vid;
	double dist;
} personaje_t;

typedef struct {
	double x_i;
	double y_i;
	double vel;
	bool viva;
} mosca_t;

typedef struct chocables {
	personaje_t *per;
	mosca_t *mos;
	struct chocables *sig_chocables;
	struct chocables *ant_chocables;
} chocables_t;

int leer_personajes(personaje_t *pers);
int leer_moscas(mosca_t *moscas);
chocables_t *crear_chocables();
int preprocesamiento(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos, chocables_t **chocables_inicial);
int procesar_chocables(chocables_t *chocables);
void borrar_chocables(chocables_t **chocables_inicial, chocables_t **chocables_actual);
bool avanzar_iteracion(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos);
int procesar(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos);
int comparar(const void *personaje_1, const void *personaje_2);
void mostrar_resultados(personaje_t *personajes, int cant_pers, int muertos);

int leer_personajes(personaje_t *pers) {
	// leer achivo personajes.txt y rellenar el arreglo de personajes, devuelve cantidad de personajes leidos o -1 en caso de error
	FILE* archivo;
	if( !( archivo = fopen("personajes.txt", "r") ) ){
        fprintf(stderr, "No se encontro el archivo de input de personajes\n");
		return -1;
	}
	int res_leer_linea = 1;
	int personajes_leidos = 0;
	while (	res_leer_linea != EOF && personajes_leidos < N_PER) {
		memset(pers[personajes_leidos].id, 0, MAX_ID);
		res_leer_linea = fscanf(archivo, "%s %lf %lf %lf %lf %d", (pers[personajes_leidos].id), &(pers[personajes_leidos].x_i), &(pers[personajes_leidos].x_d), &(pers[personajes_leidos].y_d), &(pers[personajes_leidos].vel), &(pers[personajes_leidos].vid));
		if (res_leer_linea != EOF) {
			pers[personajes_leidos].dist = 0;
			personajes_leidos += 1;
			if (pers[personajes_leidos].vel > MAX_VEL)
				MAX_VEL = pers[personajes_leidos].vel;
		}
	}

	fclose(archivo);
	return personajes_leidos;
}

int leer_moscas(mosca_t *moscas) {
	// leer achivo moscas.txt y rellenar el arreglo de moscas, devuelve cantidad de moscas leidas o -1 en caso de error
	FILE* archivo;
	if( !( archivo = fopen("moscas.txt", "r") ) ){
        fprintf(stderr, "No se encontro el archivo de input de moscas\n");
		return -1;
	}
	int res_leer_linea = 1;
	int moscas_leidas = 0;
	while (	res_leer_linea != EOF && moscas_leidas < N_MOS) {
		res_leer_linea = fscanf(archivo, "%lf %lf", &(moscas[moscas_leidas].x_i), &(moscas[moscas_leidas].y_i));
		if (res_leer_linea != EOF){
			moscas[moscas_leidas].vel = -1 * VEL_MOSCA;
			moscas[moscas_leidas].viva = true;
			moscas_leidas += 1;
		}
	}

	MAX_VEL = MAX_VEL < VEL_MOSCA ? VEL_MOSCA : MAX_VEL;	

	fclose(archivo);
	return moscas_leidas;
}

chocables_t *crear_chocables() {
	chocables_t *chocables_nuevo = malloc(sizeof(chocables_t));
	chocables_nuevo->sig_chocables = NULL;
	chocables_nuevo->ant_chocables = NULL;
	return chocables_nuevo;
}

int preprocesamiento(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos, chocables_t **chocables_inicial) {
	//cargar la lista enlazada con las combinaciones de personajes y moscas
	MAX_DIVISION = MAX_VEL > 0 ? MAX_VEL * 100.0 : 1.0f;
	int cant_pers_y_moscas = 0;
	int itr_per = 0;
	int itr_mos = 0;
	*chocables_inicial = crear_chocables();
	chocables_t* chocables_aux = *chocables_inicial;
	chocables_aux->sig_chocables = *chocables_inicial;
	while (itr_mos < n_mos) {
		moscas[itr_mos].vel /= MAX_DIVISION;
		itr_mos++;
	}
	itr_mos = 0;
	while (itr_per < n_pers) {
		while (itr_mos < n_mos) {
			chocables_aux = chocables_aux->sig_chocables;
			chocables_aux->per = &personajes[itr_per];
			chocables_aux->mos = &moscas[itr_mos];
			chocables_aux->sig_chocables = crear_chocables();
			chocables_aux->sig_chocables->ant_chocables = chocables_aux;
			cant_pers_y_moscas++;
			itr_mos++;
		}
		personajes[itr_per].vel /= MAX_DIVISION;
		itr_per++;
		itr_mos = 0;
	}
	if (cant_pers_y_moscas > 0) {
		free(chocables_aux->sig_chocables);
		chocables_aux->sig_chocables = NULL;
	} else {
		free(*chocables_inicial);
		*chocables_inicial = NULL;
	}
	printf("\nEn total tengo %d chocables\n", cant_pers_y_moscas);
	return cant_pers_y_moscas;
}

int procesar_chocables(chocables_t *chocables) {
	int borrar_chocable = 0;
	if (!chocables->mos->viva || chocables->per->vid == 0 || chocables->per->y_d < chocables->mos->y_i || chocables->per->x_i > chocables->mos->x_i + LADO_MOSCA) {
		//Es imposible que choquen (mosca muerta, personaje muerto, mosca mas arriba que el personaje, mosca a la izquierda del personaje)
		printf("Choque imposible\n");
		borrar_chocable = 1;
	} else if (chocables->per->x_d > chocables->mos->x_i) {
		//se chocaron
		chocables->per->vid -= 1;
		chocables->mos->viva = false;
		borrar_chocable = 1;
		printf("Chocaron\n");
	}
	return borrar_chocable;
}

void borrar_chocables(chocables_t **chocables_inicial, chocables_t **chocables_actual) {
	//Elimina el elemento chocables actual
	chocables_t *chocables_aux;
	if (*chocables_actual == *chocables_inicial) {
		chocables_aux = (*chocables_inicial)->sig_chocables;
		free(*chocables_inicial);
		*chocables_inicial = chocables_aux;
		*chocables_actual = *chocables_inicial;
		if (chocables_aux)	//Si el primer elemento no era el unico de la lista
			(*chocables_inicial)->ant_chocables = NULL;
		return;
	}
	chocables_aux = (*chocables_actual)->ant_chocables;
	chocables_aux->sig_chocables = (*chocables_actual)->sig_chocables;
	if (chocables_aux->sig_chocables)	//Si el elemento a borrar no es el ultimo elemento de la lista
		chocables_aux->sig_chocables->ant_chocables = chocables_aux;
	free(*chocables_actual);
	*chocables_actual = NULL;
	return;

}

bool avanzar_iteracion(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos) {
	int itr_per = 0;
	int itr_mos = 0;
	bool todos_muertos = true;
	while (itr_per < n_pers) {
		if (personajes[itr_per].vid > 0) {
			todos_muertos = false;
			personajes[itr_per].x_i += personajes[itr_per].vel;
			personajes[itr_per].x_d += personajes[itr_per].vel;
			personajes[itr_per].dist += personajes[itr_per].vel;
		}
		itr_per++;
	}
	while (itr_mos < n_mos) {
		if (moscas[itr_mos].viva) {
			moscas[itr_mos].x_i += moscas[itr_mos].vel;
		}
		itr_mos++;
	}
	return todos_muertos;
}

int procesar(personaje_t *personajes, int n_pers, mosca_t *moscas, int n_mos) {
	//procesar hasta que todos los personajes se mueran o hasta que pasen 1000*20 actualizaciones (20 seg)
	chocables_t *chocables_inicial = NULL;
	int cant_pers_y_moscas = preprocesamiento(personajes, n_pers, moscas, n_mos, &chocables_inicial);

	//Procesamiento de chocables en las 20000 iteraciones
	chocables_t *chocables_actual = chocables_inicial;
	chocables_t *chocables_aux = chocables_inicial;

	double contador = 0;
	int contador_chocables_destruidos = 0;
	int res_choq = 0;
	bool todos_muertos = false;
	while (chocables_inicial != NULL && contador < 20*MAX_DIVISION && !todos_muertos) {
		//Pruebo si se van a chocar las combinaciones de moscas y personajes, devuelve si debo o no borrar ese par de personaje-mosca
		res_choq = procesar_chocables(chocables_actual);
		chocables_aux = chocables_actual;
		if (chocables_inicial) {
			if (chocables_actual->sig_chocables == NULL){
				todos_muertos = avanzar_iteracion(personajes, n_pers, moscas, n_mos);
				chocables_actual = chocables_inicial;
				contador++;
			}
			else
				chocables_actual = chocables_actual->sig_chocables;
		} 

		if (res_choq) {
			printf("Borrando chocable: %d\n\n", ++contador_chocables_destruidos);
			borrar_chocables(&chocables_inicial, &chocables_aux);
		}

	}

	while(chocables_inicial != NULL) {
		borrar_chocables(&chocables_inicial, &chocables_inicial);
	}

	if (contador < 20*MAX_DIVISION && !todos_muertos) {
		todos_muertos = avanzar_iteracion(personajes, n_pers, moscas, n_mos);
		contador++;
	}
	
	int itr_per = 0;
	int muertos = 0;
	while (itr_per < n_pers) {
		if (personajes[itr_per].vid == 0) 
			++muertos;

		itr_per++;
	}

	return muertos;
}

int comparar(const void *personaje_1, const void *personaje_2) {
	//positive if p1_dist > p2_dist
	personaje_t *p1 = (personaje_t *)personaje_1;
	personaje_t *p2 = (personaje_t *)personaje_2;
	if (p1->vid == 0 && p2->vid == 0)
		return (int)(p1->dist - p2->dist);
}

void mostrar_resultados(personaje_t *personajes, int cant_pers, int muertos) {
	// ordenar de forma descendente los personajes con vidas = 0 e imprimir su id y distancia recorrida

	printf("Fin procesamiento\n");
	for (int i=0; i<cant_pers; ++i) {
		printf("Per %s en: (%.2lf, %.2lf), con vel %.2lf y vidas %d, dist: %.2lf\n", personajes[i].id, personajes[i].x_i, personajes[i].y_d, personajes[i].vel, personajes[i].vid, personajes[i].dist);
	}

	int itr_per = 0;
	int itr_muertos = 0;
	personaje_t *personajes_muertos = malloc(muertos*sizeof(personaje_t));
	while (itr_per < cant_pers && itr_muertos < muertos) {
		if (personajes[itr_per].vid == 0) {
			personajes_muertos[itr_muertos++] = personajes[itr_per];
		}
		itr_per++;
	}
	printf("muertos: %d\n", muertos);
	qsort(personajes_muertos, muertos, sizeof(personaje_t), comparar);
	for (int i = 0; i < muertos; ++i) {
		fprintf(stdout, "%s: %.4lf\n", personajes_muertos[i].id, personajes_muertos[i].dist);
	}
	free(personajes_muertos);
}

int main() {
	personaje_t personajes[N_PER];
	mosca_t moscas[N_MOS];
	
	int cant_pers;
	if ((cant_pers = leer_personajes(personajes)) < 0) {
		printf("error al leer personajes\n");
		return -1;			
	}
	printf("Lei %d personajes.\n", cant_pers);
	for (int i=0; i<cant_pers; ++i) {
		printf("Per %s en: (%.2lf, %lf), con vel %.2lf y vidas %d\n", personajes[i].id, personajes[i].x_i, personajes[i].y_d, personajes[i].vel, personajes[i].vid);
	}
	
	int cant_mos;
	if ((cant_mos = leer_moscas(moscas)) < 0){
		printf("error al leer personajes\n");
		return -1;
	}
	printf("\nLei %d mos.\n", cant_mos);
	for (int i=0; i<cant_mos; ++i) {
		printf("Mos %d en: (%.2lf, %lf), con vel %.2lf y viva: %d\n", i, moscas[i].x_i, moscas[i].y_i, moscas[i].vel, moscas[i].viva);
	}

	int muertos = procesar(personajes, cant_pers, moscas, cant_mos);
	mostrar_resultados(personajes, cant_pers, muertos);

	return 0;

}
