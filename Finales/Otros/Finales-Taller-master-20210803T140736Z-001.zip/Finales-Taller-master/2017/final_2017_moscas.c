#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

const int MAX_ENEMIGOS = 25;
const int VEL_ENEMIGOS = 10;
const int ALTO_ANCHO_ENEMIGOS = 1;
const int MAX_PERSONAJES = 8;

typedef struct {

	double xi0;
	double xi;
	double yi;
	int alto_ancho;
	double vel;
}Enemigo;


struct Personaje{

	char id[20];
	double xi0;
	double xd0;
	double xi;
	double xd;
	double yi;
	double yd;
	double vel;
	int vidas;
	double distancia;
};




int inicializaEnemigos(Enemigo *enemigos);
int inicializaPersonajes(struct Personaje *personajes);
bool seguir(struct Personaje *personajes,int cant_enemigos,int cant_personajes, time_t ini);
void manejarColision(Enemigo *enemigos, int *cant_enemigos,struct Personaje *personajes, int cant_personajes);
void quitarDelVectorEnemigos(Enemigo *enemigos, int cantidad,int pos);
bool hayColision(Enemigo enemigo,struct Personaje personaje);
int comparar(const void *a, const void *b);
void imprimirListado(struct Personaje *personajes,int cantidad);
void actualizarEnemigos(Enemigo *enemigos,int cantidad,clock_t tiempo);
void actualizarPersonajes(struct Personaje *personajes,int cantidad,clock_t tiempo);


int main(){

	time_t empezar;
    empezar = time(NULL);

    clock_t t1;

	Enemigo enemigos[MAX_ENEMIGOS];
	struct Personaje personajes[MAX_PERSONAJES];

	int cant_enemigos;
	int cant_personajes;

	//Inicializar Enemigos
	
	cant_enemigos = inicializaEnemigos(enemigos);


	//Inicializar Personajes
	cant_personajes = inicializaPersonajes(personajes);

    t1 = clock();


	while ( seguir(personajes,cant_personajes,cant_enemigos,empezar) ){

		actualizarPersonajes(personajes,cant_personajes,t1);
		manejarColision(enemigos,&cant_enemigos,personajes,cant_personajes);
		actualizarEnemigos(enemigos,cant_enemigos,t1);
		manejarColision(enemigos,&cant_enemigos,personajes,cant_personajes);
		
	}

	imprimirListado(personajes,cant_personajes);

	return 0;
}

int inicializaEnemigos(Enemigo *enemigos){

	FILE *archivo_enemigos;
	char linea[256];
	int i = 0;

	if ( ( archivo_enemigos = fopen("/home/alfonso/Escritorio/Final Taller/moscas.txt","r") ) == NULL ){
		printf("No se pudo abrir el archivo.");
		exit(1);
	}

	while ( fgets(linea,sizeof(linea),archivo_enemigos) ){

		sscanf(linea,"%lf %lf\n",&enemigos[i].xi0,&enemigos[i].yi);

		enemigos[i].alto_ancho = ALTO_ANCHO_ENEMIGOS;
		enemigos[i].vel = VEL_ENEMIGOS;

		i++;
	}

	fclose(archivo_enemigos);

	return i;

}

int inicializaPersonajes(struct Personaje *personajes){

	FILE *archivo_personajes;
	char linea[256];
	int i = 0;

	if ( ( archivo_personajes = fopen("/home/alfonso/Escritorio/Final Taller/personajes.txt","r") ) == NULL ){
		printf("No se pudo abrir el archivo.");
		exit(1);
	}

	while ( fgets(linea,sizeof(linea),archivo_personajes) ){

		sscanf(linea,"%s %lf %lf %lf %lf %d\n",personajes[i].id,&personajes[i].xi0,
			&personajes[i].xd0,&personajes[i].yd,&personajes[i].vel,&personajes[i].vidas);

		i++;
	}

	fclose(archivo_personajes);

	return i;

} 


bool seguir(struct Personaje *personajes,int cant_enemigos,int cant_personajes, time_t ini){

	int cant_per = 0;
	time_t terminar;
    terminar = time(NULL);

    for(int i = 0; i < cant_personajes; i++ ){
    	
    	if (personajes[i].vidas > 0) cant_per++;
    }


	return ( ( cant_per > 0 || cant_enemigos > 0 ) && difftime(terminar, ini) < 20.0 );
}

void manejarColision(Enemigo *enemigos, int *cant_enemigos,struct Personaje *personajes, int cant_personajes){

	for(int i = 0;i < cant_personajes;i++){
		for(int j = 0;j < *cant_enemigos;j++){
			
			if ( ( hayColision(enemigos[j],personajes[i] ) ) && personajes[i].vidas > 0 ){
				personajes[i].vidas--;

				quitarDelVectorEnemigos(enemigos,*cant_enemigos,j);
				*cant_enemigos = *cant_enemigos - 1;
				j--;
				
				if ( personajes[i].vidas <= 0 ){
					personajes[i].distancia = personajes[i].xi - personajes[i].xi0;
				}

			}

		}		
	}
}

void quitarDelVectorEnemigos(Enemigo *enemigos, int cantidad,int pos){

	for( int i = pos; i < cantidad-1;i++){

		enemigos[i] = enemigos[i+1];
	}
}


bool hayColision(Enemigo enemigo,struct Personaje personaje){



	if(( personaje.xd >= enemigo.xi ) && ( enemigo.xi >= personaje.xi )  && ( personaje.yd  >= enemigo.yi )){
		return true;
	}

	else if(( personaje.xd >= enemigo.xi + enemigo.alto_ancho ) && ( enemigo.xi + enemigo.alto_ancho >= personaje.xi )  && ( personaje.yd  >= enemigo.yi )){
		return true;
	}

	return false;
}

int comparar(const void *a, const void *b){

	struct Personaje *p1 = (struct Personaje*)a;
	struct Personaje *p2 = (struct Personaje*)b;

	return (int)(100.f*(p1->distancia - p2->distancia));
}

void imprimirListado(struct Personaje *personajes, int cantidad){


	qsort(personajes,cantidad,sizeof(struct Personaje),comparar);


	for(int i = 0; i < cantidad;i++){

		if( personajes[i].vidas <= 0 ){			

			printf("Personaje:%s\t\t\tDistancia: %lf\n",personajes[i].id,personajes[i].distancia);
		}
	}
}

void actualizarEnemigos(Enemigo *enemigos,int cantidad,clock_t tiempo){

	clock_t t2;
   	t2 = clock();

	double t = (double)(t2 -tiempo)  / CLOCKS_PER_SEC;

	for(int i = 0; i < cantidad; i++){

		enemigos[i].xi = enemigos[i].xi0 - enemigos[i].vel * t; 
	}


}

void actualizarPersonajes(struct Personaje *personajes,int cantidad,clock_t tiempo){

	clock_t t2;
    t2 = clock();

	double t = (double)(t2-tiempo) / CLOCKS_PER_SEC;

	for(int i = 0; i < cantidad; i++){

		if ( personajes[i].vidas > 0 ){

			personajes[i].xi = personajes[i].xi0 + personajes[i].vel * t; 
			personajes[i].xd = personajes[i].xd0 + personajes[i].vel * t;
		}	

	}
}

