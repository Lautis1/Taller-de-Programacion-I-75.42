#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define MAX_DISP 100
#define MAX_TEJOS 100
#define TAM_STR 256

const double pi = 3.14159265358979;
const double paso = 0.005;

int c_t = 0;
int c_d = 0;

typedef struct disp{
    char id[TAM_STR];
    double x0;
    double y0;
    double x1;
    double y1;
} disp_t;

typedef struct tejo{
    char id[TAM_STR];
    double xc;
    double yc;
    double r;
    disp_t* disp;
    double distancia; 
} tejo_t;

bool abrir_archivo( char* ruta, void** arreglo, void(*funcion)(FILE*, void**, int) ){
    FILE* archivo = fopen(ruta, "r");
    
    if(!archivo){
        return false;
    }
    
    for(int i = 0; !feof(archivo); i += 1){
        funcion(archivo, arreglo, i);
    }
    
    fclose(archivo);
    return true;
}

void cargar_tejos_aux(FILE* archivo, tejo_t** t, int i){
    t[i] = malloc( sizeof(tejo_t) );
    fscanf(archivo, "%s %lf %lf %lf", t[i]->id, &t[i]->xc, &t[i]->yc, &t[i]->r);
    t[i]->disp = NULL;
    t[i]->distancia = 0;
    c_t += 1;
}

bool cargar_tejos(char* ruta, tejo_t** t){
    return abrir_archivo( ruta, (void**) t, ( void(*)(FILE*, void**, int) ) cargar_tejos_aux );
}

void cargar_disp_aux(FILE* archivo, disp_t** d, int i){
    d[i] = malloc( sizeof(disp_t) );
    fscanf(archivo, "%s %lf %lf %lf %lf", d[i]->id, &d[i]->x0, &d[i]->y0, &d[i]->y1, &d[i]->x1);
    d[i]->x1 += d[i]->x0;
    d[i]->y1 += d[i]->y0;
    c_d += 1;
}

bool cargar_disp(char* ruta, disp_t** d){
    return abrir_archivo( ruta, (void**) d, ( void(*)(FILE*, void**, int) ) cargar_disp_aux );
}

void liberar(tejo_t** t, disp_t** d){
    for(int i = 0; i < c_t; i += 1){
        free( t[i] );
    }
    
    for(int i = 0; i < c_d; i += 1){
        free( d[i] );
    }
    
    free(t);
    free(d);
}

bool hay_movimiento(tejo_t** t){
    for(int i = 0; i < c_t; i += 1){
        if( !t[i]->disp ){
            return true;
        }
    }
    
    return false;
}

bool hay_disp(tejo_t** t, double max_x_disp){
    for(int i = 0; i < c_t; i += 1){
        // Si hay un tejo que todavía tiene un
        // disp adelante.
        if( ( !t[i]->disp )   &&   ( ( t[i]->xc + t[i]->r ) <= max_x_disp ) ){
            return true;
        }
    }
    
    return false;
}

void mover_t(tejo_t* t){
    if(t->disp){
        return;
    }
    
    t->xc += paso;
    t->distancia += paso;
}

bool hay_colision(tejo_t* t, disp_t* d){
    // No se puede chocar dos veces
    if(t->disp){
        return false;
    }
    
    double arriba = 5 * pi / 2; // pi / 2
    double abajo = 3 * pi / 2; 
    
    for(double a = abajo; a < arriba; a += paso){
        double x = t->xc + t->r * cos(a);
        double y = t->yc + t->r * sin(a);
        
        if( (x >= d->x0) &&  (x <= d->x1)  && (y >= d->y0) &&  (y <= d->y1) ){
            return true;
        }
    }
    
    return false;
}

void actualizar(tejo_t** t, disp_t** d, double max_x_disp){
    // Condición de corte: hay al menos un tejo que no chocó
    // y existe un disp más adelante (independientemente si puede
    // llegar a colisionar o no.
    while( hay_movimiento(t) && hay_disp(t, max_x_disp) ){
        for(int i = 0; i < c_t; i += 1){
            for(int j = 0; j < c_d; j += 1){
                if( hay_colision( t[i], d[j] ) ){
                    t[i]->disp = d[j];
                }
            }
        }
        
        for(int i = 0; i < c_t; i += 1){
            mover_t( t[i] );
        }
    }
}

double get_max_x_disp(disp_t** d){
    double max_x = -1;
    
    for(int i = 0; i < c_d; i += 1){
        if( d[i]->x1 > max_x ){
            max_x = d[i]->x1;
        }
    }
    
    return max_x;
}

int comparar_tejo(const void* a, const void* b){
    tejo_t* t1 = * ( (tejo_t**) a );
    tejo_t* t2 = * ( (tejo_t**) b );
    
    if( t1->distancia > t2->distancia ){
        return 1;
    }
    
    if( t1->distancia < t2->distancia ){
        return -1;
    }
    
    return 0;
}

void imprimir_tejos(tejo_t** t){
    qsort(t, c_t, sizeof(tejo_t*), comparar_tejo);
    
    for(int i = 0; i < c_t; i += 1){
        if( t[i]->disp ){
            printf("%s %s %lf \n", t[i]->id, t[i]->disp->id, t[i]->distancia); 
        }
    }
}

int main(int argc, char* argv[]){
    (void) argc;
    tejo_t** t = malloc( sizeof(tejo_t) * MAX_TEJOS );
    disp_t** d = malloc( sizeof(disp_t) * MAX_DISP );
    
    if( ( !cargar_tejos( argv[1], t ) ) || ( !cargar_disp( argv[2], d ) ) ){
        printf("Archivo no encontrado.\n");
        return 1;
    }
    
    double max_x_disp = get_max_x_disp(d);
   
    actualizar(t, d, max_x_disp);
    imprimir_tejos(t);
    
    liberar(t, d);
    return 0;
}
