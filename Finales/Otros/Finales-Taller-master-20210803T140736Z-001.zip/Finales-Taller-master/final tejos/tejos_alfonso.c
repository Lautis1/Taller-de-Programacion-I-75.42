#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#include<math.h>

struct Dispersor{
	char id[20];
	double x;
	double y;
	double alto;
	double ancho;
};

struct Tejo{
	char id_tejo[20];
	double x;
	double y;
	double radio;
	double distancia;
	bool choco;
	bool termino;
	char id_disp[20];

};

#define DESPLAZAMIENTO 0.0001;

static int cant_dispersores = 0;
static int cant_tejos = 0;

struct Dispersor **dispersores = NULL;
struct Tejo **tejos = NULL;

//Funciones para crear tejos
void inicializarTejos(char* nombre_archivo);
void crearVectorTejos();

//Funciones para crear Dispersores
void inicializarDispersores(char* nombre_archivo);
void crearVectorDispersores();

//Funciones para el actualizar:
void actualizar();
bool continuar();
void verificarColisiones();
void avanzar();
bool hayColision(int nro_tejo,int nombre_dispersores);
bool comprobarSiTermino(int pos);

//Funciones para mostrar informacion:
void mostrar();
int comparar(const void* a,const void* b);

//Funciones para liberar memoria:
void libera();

int main(int argc, char* argv[]){

	if ( argc != 3 ){
		printf("%s\n","Error: Cantidad de argumentos invalida, pasar solamente el nombre de los dos archivos." );
		exit(1);
	}

	//Inicializar vector de tejos 
	inicializarTejos(argv[1]);

	//Inicializar vector de dispersores 
	inicializarDispersores(argv[2]);

	//Actualizar:
	actualizar();



	//Imprimir solucion:
	mostrar();

	//Liberar memoria:
	libera();


	return 0;
}


void inicializarTejos(char* nombre_archivo){

	FILE* archivo;
	char linea[256];
	int i = 0;
	archivo = fopen(nombre_archivo,"r");

	if (  archivo == NULL ){
		printf("Error: No se pudo abrir el archivo %s \n",nombre_archivo);
		exit(1);
	}

	while( fgets(linea,sizeof(linea),archivo) ){
		cant_tejos++;
	}

	rewind(archivo);

	crearVectorTejos();

	while( fgets(linea,sizeof(linea),archivo) ){
		sscanf(linea,"%s %lf %lf %lf\n",tejos[i]->id_tejo,&tejos[i]->x,&tejos[i]->y,&tejos[i]->radio);

		tejos[i]->distancia = 0.0;
		tejos[i]->choco = false;
		tejos[i]->termino = false;
		strcpy(tejos[i]->id_disp,"");

		i++;
	}

	fclose(archivo);
}


void crearVectorTejos(){

	tejos = malloc(sizeof(struct Tejo) * cant_tejos);

	for( int i = 0; i < cant_tejos; i++  ){

		tejos[i] = malloc(sizeof(struct Tejo));
	}

}

void inicializarDispersores(char* nombre_archivo){

	FILE* archivo;
	char linea[256];
	int i = 0;
	archivo = fopen(nombre_archivo,"r");


	if (  archivo == NULL ){
		printf("Error: No se pudo abrir el archivo %s \n",nombre_archivo);
		exit(1);
	}

	while( fgets(linea,sizeof(linea),archivo) ){
		cant_dispersores++;
	}

	rewind(archivo);

	crearVectorDispersores();

	while( ! feof(archivo) ){
		fscanf(archivo,"%s %lf %lf %lf %lf\n",dispersores[i]->id, &dispersores[i]->x,&dispersores[i]->y,&dispersores[i]->alto,&dispersores[i]->ancho);
		i++;
	}

	fclose(archivo);
}


void crearVectorDispersores(){

	dispersores = malloc(sizeof(struct Dispersor) * cant_dispersores);

	for( int i = 0; i < cant_dispersores; i++  ){

		dispersores[i] =malloc(sizeof(struct Dispersor));
	}

}

void actualizar(){


	while ( continuar() ){

		verificarColisiones();
		avanzar();
	}

}

bool continuar(){

	for(int i = 0; i < cant_tejos; i++){

		if ( ! tejos[i]->termino ){
			return true;
		}

	}

	return false;
}


void verificarColisiones(){

	for(int i = 0; i < cant_tejos; i++){
		for(int j = 0; j < cant_dispersores; j++){
			
			if ( tejos[i]->termino ){
				break;
			}

			else if ( hayColision(i,j) ){
				tejos[i]->choco = true;
				tejos[i]->termino = true;
				strcpy(tejos[i]->id_disp,dispersores[j]->id);
			}

		}
	}
}

bool hayColision(int pos_tejo,int pos_disp){

	double distancia_x = fabs(dispersores[pos_disp]->x - tejos[pos_tejo]->x);
	double distancia_cm_vii = fabs( ( dispersores[pos_disp]->y - tejos[pos_tejo]->y  ) );
	double distancia_cm_vsi = fabs( ( tejos[pos_tejo]->y - ( dispersores[pos_disp]->y + dispersores[pos_disp]->alto ) ) );

	double distancia_circulo_vertice_arriba = sqrt( pow(distancia_x,2) + pow(distancia_cm_vsi,2) );
	double distancia_circulo_vertice_abajo = sqrt( pow(distancia_x,2) + pow(distancia_cm_vii,2) );

	if ( (distancia_x <= tejos[pos_tejo]->radio) && (tejos[pos_tejo]->y <= (dispersores[pos_disp]->y + dispersores[pos_disp]->alto )) &&  (tejos[pos_tejo]->y >= dispersores[pos_disp]->y )){
		return true;
	}
	else if (distancia_circulo_vertice_arriba <= tejos[pos_tejo]->radio){
		return true;
	}
	else if (distancia_circulo_vertice_abajo <= tejos[pos_tejo]->radio){
		return true;
	}

	return false;
}

void avanzar(){

	for(int i = 0; i < cant_tejos;i++){
		if ( ! tejos[i]->termino ){
			tejos[i]->x += DESPLAZAMIENTO;
			tejos[i]->distancia += DESPLAZAMIENTO;
			tejos[i]->termino = comprobarSiTermino(i);

		}

	}
}

bool comprobarSiTermino(int pos){

	for(int i = 0; i < cant_dispersores;i++){

		if ( ( tejos[pos]->x - tejos[pos]->radio ) <= ( dispersores[i]->x + dispersores[i]->ancho ) ){
			return false;
		}

	}

	return true;
}

void mostrar(){

	qsort(tejos,cant_tejos,sizeof(struct Tejo*),comparar);

	for(int i = 0; i < cant_tejos; i++){
		if ( tejos[i]->choco ){
			printf("Id Tejo: %s; Id Dispersor: %s; Distancia: %lf\n",tejos[i]->id_tejo,tejos[i]->id_disp,tejos[i]->distancia);
		}
	}

}

int comparar(const void *a,const void *b){

	struct Tejo* t1 = *(struct Tejo**)a;
	struct Tejo* t2 = *(struct Tejo**)b;

	return ((int)( t1->distancia > t2->distancia ));
}


void libera(){

	for(int i = 0; i < cant_tejos; i++){
		free(tejos[i]);
	}
	free(tejos);


	for(int i = 0; i < cant_dispersores; i++){
		free(dispersores[i]);
	}
	free(dispersores);

}